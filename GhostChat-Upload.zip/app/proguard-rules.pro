# Preview build keeps minification disabled. Add release rules after network transport is selected.
