package com.ghostchat.android.data

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.Executors
import java.util.concurrent.Future
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * A small SharedPreferences-compatible vault. Only an AES-GCM ciphertext is stored in ordinary
 * SharedPreferences; the AES-256 key is created and kept by Android Keystore and never exported.
 * The backing preference file must remain excluded from backups (the app disables Auto Backup).
 */
internal class AndroidKeyStorePreferences(context: Context, fileName: String) : SharedPreferences {
    private companion object {
        const val PAYLOAD_KEY = "ciphertext_v1"
        const val FORMAT_VERSION: Byte = 1
        const val IV_LENGTH_BYTES = 12
        const val TAG_LENGTH_BITS = 128
    }

    private val backing = context.applicationContext.getSharedPreferences("${fileName}_vault", Context.MODE_PRIVATE)
    private val key: SecretKey = getOrCreateKey("${context.packageName}.ghostchat.preferences.v1")
    private val stateLock = Any()
    private val listeners = CopyOnWriteArraySet<SharedPreferences.OnSharedPreferenceChangeListener>()
    private val writer = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "ghostchat-encrypted-prefs").apply { isDaemon = true }
    }
    private var values: MutableMap<String, Any> = readInitialValues()

    override fun getAll(): MutableMap<String, *> = synchronized(stateLock) { deepCopy(values) }

    override fun getString(key: String?, defValue: String?): String? = synchronized(stateLock) {
        (key?.let(values::get) as? String) ?: defValue
    }

    override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? = synchronized(stateLock) {
        val stored = key?.let(values::get) as? Set<*>
        if (stored == null) defValues?.toMutableSet()
        else stored.filterIsInstance<String>().toMutableSet()
    }

    override fun getInt(key: String?, defValue: Int): Int = synchronized(stateLock) {
        (key?.let(values::get) as? Int) ?: defValue
    }

    override fun getLong(key: String?, defValue: Long): Long = synchronized(stateLock) {
        (key?.let(values::get) as? Long) ?: defValue
    }

    override fun getFloat(key: String?, defValue: Float): Float = synchronized(stateLock) {
        (key?.let(values::get) as? Float) ?: defValue
    }

    override fun getBoolean(key: String?, defValue: Boolean): Boolean = synchronized(stateLock) {
        (key?.let(values::get) as? Boolean) ?: defValue
    }

    override fun contains(key: String?): Boolean = synchronized(stateLock) { key != null && values.containsKey(key) }

    override fun edit(): SharedPreferences.Editor = VaultEditor()

    override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) listeners.add(listener)
    }

    override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) listeners.remove(listener)
    }

    private inner class VaultEditor : SharedPreferences.Editor {
        private val updates = linkedMapOf<String, Any?>()
        private var clearRequested = false

        override fun putString(key: String?, value: String?): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = value
        }

        override fun putStringSet(key: String?, values: MutableSet<String>?): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = values?.toMutableSet()
        }

        override fun putInt(key: String?, value: Int): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = value
        }

        override fun putLong(key: String?, value: Long): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = value
        }

        override fun putFloat(key: String?, value: Float): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = value
        }

        override fun putBoolean(key: String?, value: Boolean): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = value
        }

        override fun remove(key: String?): SharedPreferences.Editor = apply {
            if (key != null) updates[key] = null
        }

        override fun clear(): SharedPreferences.Editor = apply { clearRequested = true }

        override fun commit(): Boolean {
            val (snapshot, changedKeys) = applyUpdates(clearRequested, updates)
            notifyListeners(changedKeys)
            return try {
                writer.submit<Boolean> { persistSnapshot(snapshot) }.get()
            } catch (_: Exception) {
                false
            }
        }

        override fun apply() {
            val (snapshot, changedKeys) = applyUpdates(clearRequested, updates)
            notifyListeners(changedKeys)
            writer.execute { persistSnapshot(snapshot) }
        }
    }

    private fun applyUpdates(
        clearRequested: Boolean,
        updates: Map<String, Any?>
    ): Pair<Map<String, Any>, Set<String>> {
        val changed = linkedSetOf<String>()
        val snapshot = synchronized(stateLock) {
            if (clearRequested) {
                changed.addAll(values.keys)
                values.clear()
            }
            updates.forEach { (name, value) ->
                if (value == null) {
                    if (values.remove(name) != null) changed.add(name)
                } else {
                    val safeValue = copyValue(value)
                    if (values[name] != safeValue) changed.add(name)
                    values[name] = safeValue
                }
            }
            deepCopy(values)
        }
        return snapshot to changed
    }

    private fun notifyListeners(keys: Set<String>) {
        keys.forEach { changedKey ->
            listeners.forEach { listener -> runCatching { listener.onSharedPreferenceChanged(this, changedKey) } }
        }
    }

    private fun readInitialValues(): MutableMap<String, Any> {
        val encrypted = backing.getString(PAYLOAD_KEY, null) ?: return linkedMapOf()
        return decode(decrypt(encrypted))
    }

    private fun persistSnapshot(snapshot: Map<String, Any>): Boolean = runCatching {
        val encrypted = encrypt(encode(snapshot))
        backing.edit().putString(PAYLOAD_KEY, encrypted).commit()
    }.getOrDefault(false)

    private fun encode(source: Map<String, Any>): ByteArray {
        val entries = JSONArray()
        source.forEach { (name, rawValue) ->
            val value = copyValue(rawValue)
            val entry = JSONObject().put("key", name)
            when (value) {
                is String -> entry.put("type", "s").put("value", value)
                is Boolean -> entry.put("type", "b").put("value", value)
                is Int -> entry.put("type", "i").put("value", value)
                is Long -> entry.put("type", "l").put("value", value)
                is Float -> entry.put("type", "f").put("value", value.toDouble())
                is Set<*> -> {
                    val items = JSONArray()
                    value.filterIsInstance<String>().forEach { item -> items.put(item) }
                    entry.put("type", "ss").put("value", items)
                }
                else -> throw IllegalArgumentException("Unsupported preference type for $name")
            }
            entries.put(entry)
        }
        return JSONObject().put("entries", entries).toString().toByteArray(StandardCharsets.UTF_8)
    }

    private fun decode(bytes: ByteArray): MutableMap<String, Any> {
        val root = JSONObject(String(bytes, StandardCharsets.UTF_8))
        val entries = root.optJSONArray("entries") ?: JSONArray()
        val output = linkedMapOf<String, Any>()
        for (index in 0 until entries.length()) {
            val entry = entries.optJSONObject(index) ?: continue
            val name = entry.optString("key")
            if (name.isBlank()) continue
            val decoded: Any? = when (entry.optString("type")) {
                "s" -> entry.optString("value", "")
                "b" -> entry.optBoolean("value", false)
                "i" -> entry.optInt("value")
                "l" -> entry.optLong("value")
                "f" -> entry.optDouble("value").toFloat()
                "ss" -> {
                    val array = entry.optJSONArray("value") ?: JSONArray()
                    buildSet {
                        for (i in 0 until array.length()) {
                            val item = array.opt(i)
                            if (item is String) add(item)
                        }
                    }
                }
                else -> null
            }
            if (decoded != null) output[name] = decoded
        }
        return output
    }

    private fun encrypt(cleartext: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(cleartext)
        val packed = ByteArray(2 + iv.size + ciphertext.size)
        packed[0] = FORMAT_VERSION
        packed[1] = iv.size.toByte()
        System.arraycopy(iv, 0, packed, 2, iv.size)
        System.arraycopy(ciphertext, 0, packed, 2 + iv.size, ciphertext.size)
        return Base64.encodeToString(packed, Base64.NO_WRAP)
    }

    private fun decrypt(encoded: String): ByteArray {
        val packed = Base64.decode(encoded, Base64.NO_WRAP)
        require(packed.size > 2 + IV_LENGTH_BYTES && packed[0] == FORMAT_VERSION) { "Unsupported encrypted preferences format" }
        val ivLength = packed[1].toInt() and 0xFF
        require(ivLength == IV_LENGTH_BYTES && packed.size > 2 + ivLength) { "Invalid encrypted preferences IV" }
        val iv = packed.copyOfRange(2, 2 + ivLength)
        val ciphertext = packed.copyOfRange(2 + ivLength, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BITS, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun getOrCreateKey(alias: String): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(alias, null)
        if (existing is SecretKey) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setKeySize(256)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun deepCopy(source: Map<String, Any>): MutableMap<String, Any> = linkedMapOf<String, Any>().apply {
        source.forEach { (name, value) -> put(name, copyValue(value)) }
    }

    private fun copyValue(value: Any): Any = when (value) {
        is Set<*> -> value.filterIsInstance<String>().toMutableSet()
        else -> value
    }
}
