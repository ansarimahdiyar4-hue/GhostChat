package com.ghostchat.android.data

import android.util.Base64
import org.json.JSONObject

/** Public Firebase client configuration. Never put admin/service-account credentials here. */
data class FirebaseProjectConfig(
    val apiKey: String,
    val appId: String,
    val projectId: String,
    val databaseUrl: String,
    val senderId: String
) {
    fun isValid(): Boolean = apiKey.isNotBlank() && appId.startsWith("1:") &&
        projectId.isNotBlank() && databaseUrl.startsWith("https://") && senderId.isNotBlank()

    /** Compact share code so a room owner can give the same Firebase project config to friends. */
    fun toShareCode(): String {
        val json = JSONObject().apply {
            put("apiKey", apiKey.trim())
            put("appId", appId.trim())
            put("projectId", projectId.trim())
            put("databaseUrl", databaseUrl.trim().trimEnd('/'))
            put("senderId", senderId.trim())
            put("format", 1)
        }
        return "GC1:" + Base64.encodeToString(json.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
    }

    companion object {
        fun fromShareCode(code: String): FirebaseProjectConfig? = runCatching {
            val raw = code.trim().removePrefix("GC1:")
            val json = JSONObject(String(Base64.decode(raw, Base64.NO_WRAP or Base64.URL_SAFE), Charsets.UTF_8))
            FirebaseProjectConfig(
                apiKey = json.optString("apiKey"),
                appId = json.optString("appId"),
                projectId = json.optString("projectId"),
                databaseUrl = json.optString("databaseUrl"),
                senderId = json.optString("senderId")
            ).takeIf { it.isValid() }
        }.getOrNull()
    }
}
