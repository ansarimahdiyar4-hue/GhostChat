package com.ghostchat.android

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.app.KeyguardManager
import android.provider.Settings
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.snap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ghostchat.android.data.ChatMessage
import com.ghostchat.android.data.ChatPrefs
import com.ghostchat.android.data.FirebaseProjectConfig
import com.ghostchat.android.data.UserProfile
import com.ghostchat.android.overlay.OverlayService
import com.ghostchat.android.network.FirebaseChatService
import com.ghostchat.android.network.FirebaseChatService.ConnectionStatus
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF070611)
private val Panel = Color(0xFF111024)
private val Panel2 = Color(0xFF1A1734)
private val NeonCyan = Color(0xFF54E8F5)
private val NeonBlue = Color(0xFF7656FF)
private val NeonPurple = Color(0xFFB36BFF)
private val NeonPink = Color(0xFFFF5DD7)
private val TextMain = Color(0xFFF4F7FF)
private val TextMuted = Color(0xFF9CA8C3)
private val Border = Color(0xFF2B3651)

private enum class Tab { HOME, CHAT, PROFILE, SETTINGS }

class MainActivity : FragmentActivity() {
    private val appLockedState = mutableStateOf(false)
    private var lockPromptShowing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ChatPrefs.init(applicationContext)
        appLockedState.value = ChatPrefs.appLockEnabled()
        applySecureWindowFlag(ChatPrefs.appLockEnabled())
        ChatPrefs.firebaseConfig()?.let { savedConfig ->
            runCatching { FirebaseChatService.configure(applicationContext, savedConfig) }
            lifecycleScope.launch {
                runCatching {
                    FirebaseChatService.connectAndSignIn()
                    val savedRoom = ChatPrefs.roomCode()
                    if (savedRoom.isNotBlank()) FirebaseChatService.joinRoom(savedRoom, ChatPrefs.profile())
                }
            }
        }
        window.statusBarColor = android.graphics.Color.rgb(8, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 10, 18)
        setContent {
            GhostTheme {
                GhostChatApp(
                    appLocked = appLockedState.value,
                    onUnlock = { requestLockAuthentication(targetEnabled = null) },
                    onRequestAppLockChange = { enabled -> requestLockAuthentication(targetEnabled = enabled) },
                    onLaunchOverlay = { launchOverlay() },
                    onShareRoom = { code -> shareRoomCode(code) },
                    onCopyRoom = { code -> copyRoomCode(code) },
                    onShareFirebaseConfig = { code -> shareFirebaseConfig(code) }
                )
            }
        }
    }

    override fun onStop() {
        // Lock the app surface whenever it leaves the foreground. The next foreground visit
        // requires an explicit biometric/device-credential action before showing chat content.
        if (ChatPrefs.appLockEnabled()) {
            appLockedState.value = true
            ChatPrefs.setAppSurfaceLocked(true)
        }
        super.onStop()
    }

    private fun applySecureWindowFlag(enabled: Boolean) {
        if (enabled) window.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_SECURE,
            android.view.WindowManager.LayoutParams.FLAG_SECURE
        ) else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun requestLockAuthentication(targetEnabled: Boolean?) {
        if (lockPromptShowing) return
        val biometricManager = BiometricManager.from(this)
        val keyguard = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val supported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            ) == BiometricManager.BIOMETRIC_SUCCESS
        } else {
            biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS || keyguard.isDeviceSecure
        }
        if (!supported) {
            Toast.makeText(
                this,
                "اول در تنظیمات اندروید، اثر انگشت یا قفل صفحه (PIN، الگو یا گذرواژه) را فعال کن.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(
                when (targetEnabled) {
                    true -> "فعال‌سازی قفل Ghost Chat"
                    false -> "غیرفعال‌سازی قفل Ghost Chat"
                    null -> "باز کردن Ghost Chat"
                }
            )
            .setSubtitle("با اثر انگشت یا قفل امن گوشی هویتت را تأیید کن")
            .apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_STRONG or
                            BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    )
                } else {
                    @Suppress("DEPRECATION")
                    setDeviceCredentialAllowed(true)
                }
            }
            .build()

        lockPromptShowing = true
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    lockPromptShowing = false
                    if (targetEnabled != null) ChatPrefs.setAppLockEnabled(targetEnabled)
                    applySecureWindowFlag(ChatPrefs.appLockEnabled())
                    appLockedState.value = false
                    ChatPrefs.setAppSurfaceLocked(false)
                    val message = when (targetEnabled) {
                        true -> "قفل برنامه فعال شد."
                        false -> "قفل برنامه غیرفعال شد."
                        null -> "خوش آمدی."
                    }
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    lockPromptShowing = false
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED && errorCode != BiometricPrompt.ERROR_CANCELED) {
                        Toast.makeText(this@MainActivity, "تأیید هویت انجام نشد: $errString", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onAuthenticationFailed() {
                    Toast.makeText(this@MainActivity, "اثر انگشت شناسایی نشد؛ دوباره تلاش کن.", Toast.LENGTH_SHORT).show()
                }
            }
        )
        prompt.authenticate(promptInfo)
    }

    private fun launchOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "مجوز نمایش روی برنامه‌های دیگر را فعال کن و دوباره برگرد.", Toast.LENGTH_LONG).show()
            return
        }
        val serviceIntent = Intent(this, OverlayService::class.java)
        runCatching { ContextCompat.startForegroundService(this, serviceIntent) }
            .onFailure { Toast.makeText(this, "شروع حباب انجام نشد: ${it.localizedMessage ?: "خطای اندروید"}", Toast.LENGTH_LONG).show() }
    }

    private fun shareRoomCode(code: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "برای ورود به اتاق Ghost Chat این کد را وارد کن: $code")
        }
        startActivity(Intent.createChooser(sendIntent, "اشتراک‌گذاری کد اتاق"))
    }

    private fun copyRoomCode(code: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Ghost Chat room", code))
        Toast.makeText(this, "کد کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun shareFirebaseConfig(code: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "کد تنظیمات اتصال مشترک Ghost Chat را در قسمت اتصال اینترنت برنامه وارد کن:\n$code\n\nاین کد اطلاعات عمومی اتصال Firebase را دارد؛ هرگز کلیدهای Admin یا Service Account را ارسال نکن.")
        }
        startActivity(Intent.createChooser(sendIntent, "اشتراک تنظیمات اتصال Ghost Chat"))
    }
}

@Composable
private fun GhostTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = NeonPurple,
        secondary = NeonPink,
        tertiary = NeonCyan,
        background = Night,
        surface = Panel,
        onPrimary = Night,
        onSecondary = Night,
        onBackground = TextMain,
        onSurface = TextMain
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    }
}

@Composable
private fun GhostChatApp(
    appLocked: Boolean,
    onUnlock: () -> Unit,
    onRequestAppLockChange: (Boolean) -> Unit,
    onLaunchOverlay: () -> Unit,
    onShareRoom: (String) -> Unit,
    onCopyRoom: (String) -> Unit,
    onShareFirebaseConfig: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile by ChatPrefs.profileFlow.collectAsState()
    val connectionStatus by FirebaseChatService.connectionStatus.collectAsState()
    var tab by rememberSaveable { mutableStateOf(if (profile.displayName.isBlank()) Tab.PROFILE else Tab.HOME) }
    var activeRoom by rememberSaveable { mutableStateOf(ChatPrefs.roomCode()) }
    var joinDialog by rememberSaveable { mutableStateOf(false) }
    var setupDialog by rememberSaveable { mutableStateOf(false) }
    var infoDialog by rememberSaveable { mutableStateOf(false) }
    var animationsEnabled by remember { mutableStateOf(ChatPrefs.animationsEnabled()) }
    var busy by remember { mutableStateOf(false) }
    var joinBusy by remember { mutableStateOf(false) }
    var setupBusy by remember { mutableStateOf(false) }
    var joinError by remember { mutableStateOf("") }
    var setupError by remember { mutableStateOf("") }
    var operationError by remember { mutableStateOf("") }
    var pendingJoinCode by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = !appLocked && (tab == Tab.CHAT || tab == Tab.SETTINGS || tab == Tab.PROFILE)) {
        tab = if (profile.displayName.isBlank()) Tab.PROFILE else Tab.HOME
    }

    fun performJoin(codeInput: String, onSuccess: () -> Unit) {
        if (busy || joinBusy) return
        val config = ChatPrefs.firebaseConfig()
        if (config == null) {
            pendingJoinCode = codeInput
            joinDialog = false
            setupError = "اول تنظیمات اتصال اینترنت را وارد کن. پس از ذخیره، ورود به این اتاق خودکار انجام می‌شود."
            setupDialog = true
            return
        }
        joinBusy = true
        joinError = ""
        scope.launch {
            try {
                FirebaseChatService.configure(context.applicationContext, config)
                val joined = FirebaseChatService.joinRoom(codeInput, profile)
                activeRoom = joined
                ChatPrefs.setRoomCode(joined)
                tab = Tab.CHAT
                onSuccess()
            } catch (e: Exception) {
                joinError = FirebaseChatService.friendlyError(e)
            } finally {
                joinBusy = false
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF21103D), Night, Color(0xFF090613))))
    ) {
        Box(
            modifier = Modifier.fillMaxSize().then(
                if (appLocked) Modifier.clearAndSetSemantics {} else Modifier
            )
        ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(WindowInsets.statusBars.asPaddingValues())
                .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
        ) {
            if (tab != Tab.CHAT) AppTopBar(profile = profile, onProfile = { tab = Tab.PROFILE })
            Crossfade(targetState = tab, animationSpec = if (animationsEnabled) tween(180) else snap(), label = "main-screen", modifier = Modifier.weight(1f)) { target ->
                when (target) {
                    Tab.HOME -> HomeScreen(
                        profile = profile,
                        connectionStatus = connectionStatus,
                        configured = ChatPrefs.firebaseConfig() != null,
                        busy = busy || joinBusy,
                        onCreateRoom = {
                            if (!busy && !joinBusy) {
                                if (ChatPrefs.firebaseConfig() == null) {
                                    setupError = "برای چت واقعی، یک پروژه Firebase لازم است. راهنما داخل فایل راه‌اندازی پروژه است."
                                    setupDialog = true
                                } else {
                                    busy = true
                                    scope.launch {
                                        try {
                                            val config = ChatPrefs.firebaseConfig() ?: throw IllegalStateException("تنظیمات Firebase پیدا نشد.")
                                            FirebaseChatService.configure(context.applicationContext, config)
                                            val code = FirebaseChatService.createRoom(profile)
                                            activeRoom = code
                                            ChatPrefs.setRoomCode(code)
                                            tab = Tab.CHAT
                                        } catch (e: Exception) {
                                            operationError = FirebaseChatService.friendlyError(e)
                                        } finally {
                                            busy = false
                                        }
                                    }
                                }
                            }
                        },
                        onJoinRoom = { joinError = ""; joinDialog = true },
                        onLaunchOverlay = onLaunchOverlay,
                        onProfile = { tab = Tab.PROFILE },
                        onSettings = { tab = Tab.SETTINGS },
                        onAbout = { infoDialog = true },
                        onConnectionSettings = { setupError = ""; setupDialog = true }
                    )
                    Tab.CHAT -> ChatScreen(
                        roomCode = activeRoom.ifBlank { ChatPrefs.roomCode() },
                        profile = profile,
                        onBack = { tab = Tab.HOME },
                        onShare = { onShareRoom(activeRoom.ifBlank { ChatPrefs.roomCode() }) },
                        onCopy = { onCopyRoom(activeRoom.ifBlank { ChatPrefs.roomCode() }) }
                    )
                    Tab.PROFILE -> ProfileScreen(
                        profile = profile,
                        onSave = { newProfile ->
                            ChatPrefs.saveProfile(newProfile)
                            tab = Tab.HOME
                            val code = ChatPrefs.roomCode()
                            if (code.isNotBlank() && FirebaseChatService.activeRoomCode() == code) {
                                scope.launch { runCatching { FirebaseChatService.joinRoom(code, newProfile) } }
                            }
                        },
                        onCancel = { tab = Tab.HOME }
                    )
                    Tab.SETTINGS -> SettingsScreen(
                        onLaunchOverlay = onLaunchOverlay,
                        onRequestAppLockChange = onRequestAppLockChange,
                        animationsEnabled = animationsEnabled,
                        onAnimationsChanged = { animationsEnabled = it },
                        connectionStatus = connectionStatus,
                        configured = ChatPrefs.firebaseConfig() != null,
                        onConnectionSettings = { setupError = ""; setupDialog = true },
                        onShareFirebaseConfig = {
                            val config = ChatPrefs.firebaseConfig()
                            if (config != null) onShareFirebaseConfig(config.toShareCode())
                            else { setupError = "ابتدا تنظیمات Firebase را ذخیره کن."; setupDialog = true }
                        }
                    )
                }
            }
            if (tab != Tab.CHAT) BottomNav(selected = tab, onSelect = { target ->
                if (target == Tab.CHAT && ChatPrefs.roomCode().isBlank()) {
                    Toast.makeText(context, "اول یک اتاق آنلاین بساز یا با کد وارد اتاق شو.", Toast.LENGTH_SHORT).show()
                } else tab = target
            })
        }

        if (joinDialog) {
            JoinRoomDialog(
                busy = joinBusy,
                error = joinError,
                onDismiss = { if (!joinBusy) joinDialog = false },
                onJoin = { code -> performJoin(code) { joinDialog = false } }
            )
        }
        if (setupDialog) {
            FirebaseConfigDialog(
                initialConfig = ChatPrefs.firebaseConfig(),
                initialError = setupError,
                busy = setupBusy,
                onDismiss = { if (!setupBusy) { setupDialog = false; setupError = "" } },
                onShareConfig = onShareFirebaseConfig,
                onSave = { newConfig ->
                    if (setupBusy) return@FirebaseConfigDialog
                    setupBusy = true
                    setupError = ""
                    try {
                        ChatPrefs.saveFirebaseConfig(newConfig)
                        FirebaseChatService.configure(context.applicationContext, newConfig)
                    } catch (e: Exception) {
                        setupBusy = false
                        setupError = FirebaseChatService.friendlyError(e)
                        return@FirebaseConfigDialog
                    }
                    scope.launch {
                        try {
                            FirebaseChatService.connectAndSignIn()
                            setupDialog = false
                            setupError = ""
                            Toast.makeText(context, "اتصال Firebase برقرار شد.", Toast.LENGTH_LONG).show()
                            if (pendingJoinCode.isNotBlank()) {
                                val code = pendingJoinCode
                                pendingJoinCode = ""
                                try {
                                    val joined = FirebaseChatService.joinRoom(code, profile)
                                    activeRoom = joined
                                    ChatPrefs.setRoomCode(joined)
                                    tab = Tab.CHAT
                                } catch (e: Exception) {
                                    operationError = FirebaseChatService.friendlyError(e)
                                }
                            }
                        } catch (e: Exception) {
                            setupError = FirebaseChatService.friendlyError(e)
                        } finally {
                            setupBusy = false
                        }
                    }
                }
            )
        }
        if (operationError.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { operationError = "" },
                containerColor = Panel,
                title = { Text("اتصال برقرار نشد", color = TextMain, fontWeight = FontWeight.Bold) },
                text = { Text(operationError, color = TextMuted) },
                confirmButton = { TextButton(onClick = { operationError = ""; setupError = ""; setupDialog = ChatPrefs.firebaseConfig() == null }) { Text("متوجه شدم", color = NeonCyan) } }
            )
        }
        if (infoDialog) {
            AlertDialog(
                onDismissRequest = { infoDialog = false },
                containerColor = Panel,
                title = { Text("درباره Ghost Chat", color = TextMain, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "این نسخه از Firebase Realtime Database برای پیام‌رسانی زنده استفاده می‌کند. هر هشت جایگاه اتاق روی دیتابیس کنترل می‌شود. برای کارکرد بین گوشی‌ها، مالک پروژه باید یک Firebase بسازد، ورود ناشناس را روشن کند و قوانین پوشه firebase/database.rules.json را منتشر کند.",
                        color = TextMuted
                    )
                },
                confirmButton = { TextButton(onClick = { infoDialog = false }) { Text("متوجه شدم") } }
            )
        }
        }
        if (appLocked) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Night
            ) {
                Box(
                    modifier = Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF21103D), Night, Color(0xFF080817)))
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 30.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ghost_logo),
                            contentDescription = "Ghost Chat",
                            modifier = Modifier.size(164.dp),
                            contentScale = ContentScale.Fit
                        )
                        Text("Ghost Chat قفل است", color = TextMain, fontWeight = FontWeight.Black, fontSize = 24.sp)
                        Text("برای محافظت از گفتگوها، هویتت را تأیید کن.", color = TextMuted, textAlign = TextAlign.Center, fontSize = 13.sp)
                        Button(
                            onClick = onUnlock,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple, contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Fingerprint, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text("باز کردن با اثر انگشت / قفل گوشی", fontWeight = FontWeight.Bold)
                        }
                        Text("برای تغییر یا خاموش کردن قفل، ابتدا وارد برنامه شو.", color = NeonPurple, fontSize = 11.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}


@Composable
private fun AppTopBar(profile: UserProfile, onProfile: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(R.drawable.ghost_logo),
            contentDescription = "Ghost Chat logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).border(1.dp, Border, RoundedCornerShape(15.dp))
        )
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("GHOST CHAT", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("FLOAT. PLAY. TALK.", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
        }
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(Panel2)
                .border(1.dp, Border, CircleShape)
                .clickable(onClick = onProfile)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(profile.avatar.ifBlank { "👻" }, fontSize = 19.sp)
            Spacer(Modifier.width(7.dp))
            Text(profile.displayName.ifBlank { "پروفایل" }, color = TextMain, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun HomeScreen(
    profile: UserProfile,
    connectionStatus: ConnectionStatus,
    configured: Boolean,
    busy: Boolean,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit,
    onLaunchOverlay: () -> Unit,
    onProfile: () -> Unit,
    onSettings: () -> Unit,
    onAbout: () -> Unit,
    onConnectionSettings: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(2.dp))
        Surface(
            modifier = Modifier.clickable(onClick = onConnectionSettings),
            color = Color(0xFF17253B),
            shape = RoundedCornerShape(50.dp),
            border = BorderStroke(1.dp, if (connectionStatus == ConnectionStatus.ONLINE) Color(0xFF287B73) else Color(0xFF66503C))
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                val dot = if (connectionStatus == ConnectionStatus.ONLINE) Color(0xFF56F0B1) else Color(0xFFFFB56D)
                Box(Modifier.size(7.dp).background(dot, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = when {
                        !configured -> "اتصال اینترنت را راه‌اندازی کن"
                        connectionStatus == ConnectionStatus.ONLINE -> "دیتابیس متصل است"
                        else -> connectionStatus.labelFa
                    },
                    fontSize = 11.sp,
                    color = Color(0xFFB8D8E6),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("بازی کن.\nجداگانه چت کن.", fontSize = 34.sp, lineHeight = 40.sp, color = TextMain, fontWeight = FontWeight.Black)
            Text("یک حباب کوچک روی بازی؛ یک اتاق برای تیم تو.", color = TextMuted, fontSize = 14.sp, lineHeight = 21.sp)
        }

        HeroCard(profile = profile)

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PrimaryAction(
                icon = Icons.Default.Groups,
                title = "ساخت اتاق جدید",
                subtitle = if (busy) "در حال ساخت اتاق آنلاین…" else "کد دعوت بساز • حداکثر ۸ نفر",
                accent = NeonCyan,
                onClick = onCreateRoom
            )
            SecondaryAction(
                icon = Icons.Default.Login,
                title = "ورود با کد اتاق",
                subtitle = "با کد، به اتاق اینترنتی دوستان بپیوند",
                onClick = onJoinRoom
            )
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A)),
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, Border)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SportsEsports, contentDescription = null, tint = NeonPurple)
                    Spacer(Modifier.width(9.dp))
                    Text("حباب شناور روی بازی", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Text("فعالش کن، برو داخل بازی و حباب را هر جا راحتی بگذار. لمس حباب، پنجره چت را باز می‌کند.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                Button(
                    onClick = onLaunchOverlay,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF21324A), contentColor = NeonCyan)
                ) {
                    Icon(Icons.Default.Message, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("فعال‌سازی حباب", fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SmallActionCard("پروفایل", "اسم و آواتار", Icons.Default.Person, Modifier.weight(1f), onProfile)
            SmallActionCard("تنظیمات", "ظاهر و رفتار", Icons.Default.Settings, Modifier.weight(1f), onSettings)
        }

        Text(
            if (configured) "همه دوستان باید از یک تنظیمات Firebase مشترک استفاده کنند. در این اتاق حداکثر ۸ جایگاه وجود دارد."
            else "برای چت واقعی، ابتدا پروژه Firebase را یک‌بار راه‌اندازی کن؛ سپس کد تنظیمات را با دوستانت به اشتراک بگذار.",
            color = if (configured) TextMuted else Color(0xFFFFC979), fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 3.dp)
        )
        Text("درباره پروژه", color = TextMuted, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onAbout).padding(vertical = 4.dp))
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun HeroCard(profile: UserProfile) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF152B45), Color(0xFF18152E), Color(0xFF2B1232))), RoundedCornerShape(28.dp))
            .border(1.dp, Color(0xFF3C4972), RoundedCornerShape(28.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Box(Modifier.size(82.dp).background(Brush.linearGradient(listOf(NeonCyan.copy(alpha = .2f), NeonPurple.copy(alpha = .24f))), CircleShape).border(1.dp, NeonCyan.copy(alpha = .55f), CircleShape))
                Image(painterResource(R.drawable.ghost_logo), "شبح Ghost Chat", contentScale = ContentScale.Crop, modifier = Modifier.size(70.dp).clip(CircleShape))
            }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.weight(1f)) {
                Text("سلام، ${profile.displayName.ifBlank { "گیمر" }}!", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("تیمت همیشه یک لمس با تو فاصله دارد.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MiniTag("چت آنلاین", NeonCyan)
                    MiniTag("۸ نفر", NeonPink)
                }
            }
        }
    }
}

@Composable
private fun MiniTag(text: String, color: Color) {
    Surface(color = color.copy(alpha = .11f), shape = RoundedCornerShape(7.dp), border = BorderStroke(1.dp, color.copy(alpha = .32f))) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
    }
}

@Composable
private fun PrimaryAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(76.dp),
        contentPadding = PaddingValues(horizontal = 15.dp, vertical = 9.dp),
        shape = RoundedCornerShape(19.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF173449), contentColor = TextMain),
        border = BorderStroke(1.dp, accent.copy(alpha = .55f))
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(29.dp))
        Spacer(Modifier.width(13.dp))
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextMain)
            Text(subtitle, fontSize = 10.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("›", color = accent, fontSize = 26.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun SecondaryAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = Panel,
        shape = RoundedCornerShape(19.dp),
        border = BorderStroke(1.dp, Border)
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextMuted, fontSize = 11.sp)
            }
            Text("›", color = NeonPurple, fontSize = 25.sp)
        }
    }
}

@Composable
private fun SmallActionCard(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(23.dp))
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(sub, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun JoinRoomDialog(
    busy: Boolean,
    error: String,
    onDismiss: () -> Unit,
    onJoin: (String) -> Unit
) {
    var code by rememberSaveable { mutableStateOf("") }
    var localError by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("ورود به اتاق آنلاین", color = TextMain, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("کد ۸ نویسه‌ای را از سازنده اتاق بگیر.", color = TextMuted, fontSize = 13.sp)
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(8); localError = "" },
                    singleLine = true,
                    label = { Text("مثلاً K7PM4X9Q") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedLabelColor = NeonCyan, unfocusedBorderColor = Border, focusedTextColor = TextMain, unfocusedTextColor = TextMain),
                    modifier = Modifier.fillMaxWidth()
                )
                if (busy) Text("در حال اتصال و ورود به اتاق…", color = NeonCyan, fontSize = 12.sp)
                if (localError.isNotBlank()) Text(localError, color = NeonPink, fontSize = 11.sp)
                if (error.isNotBlank()) Text(error, color = NeonPink, fontSize = 11.sp, lineHeight = 16.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                if (code.length != 8) localError = "کد اتاق باید دقیقاً ۸ نویسه داشته باشد." else onJoin(code)
            }) { Text(if (busy) "در حال اتصال…" else "ورود به اتاق", color = NeonCyan, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("لغو", color = TextMuted) } }
    )
}

@Composable
private fun ChatScreen(roomCode: String, profile: UserProfile, onBack: () -> Unit, onShare: () -> Unit, onCopy: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storedMessages by ChatPrefs.messagesFlow.collectAsState()
    val members by FirebaseChatService.members.collectAsState()
    val connectionStatus by FirebaseChatService.connectionStatus.collectAsState()
    val messages = storedMessages.filter { it.roomCode.equals(roomCode, ignoreCase = true) }.sortedBy { it.timestamp }
    var draft by rememberSaveable(roomCode) { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val active = FirebaseChatService.activeRoomCode().equals(roomCode, ignoreCase = true)

    DisposableEffect(roomCode) {
        if (roomCode.isNotBlank()) ChatPrefs.setRoomVisible("main-chat", roomCode, true)
        onDispose {
            if (roomCode.isNotBlank()) ChatPrefs.setRoomVisible("main-chat", roomCode, false)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 13.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            Surface(modifier = Modifier.clickable(onClick = onBack), color = Panel2, shape = CircleShape, border = BorderStroke(1.dp, Border)) {
                Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت", tint = TextMain)
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("چت گروهی زنده", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("کد: $roomCode  •  ${members.size}/۸ عضو", color = TextMuted, fontSize = 10.sp)
            }
            Surface(modifier = Modifier.clickable(onClick = onShare), color = Panel2, shape = CircleShape, border = BorderStroke(1.dp, Border)) {
                Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.Share, contentDescription = "اشتراک‌گذاری", tint = NeonCyan, modifier = Modifier.size(18.dp)) }
            }
            Spacer(Modifier.width(6.dp))
            Surface(modifier = Modifier.clickable(onClick = onCopy), color = Panel2, shape = CircleShape, border = BorderStroke(1.dp, Border)) {
                Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.ContentCopy, contentDescription = "کپی کد", tint = NeonPurple, modifier = Modifier.size(18.dp)) }
            }
        }

        val online = connectionStatus == ConnectionStatus.ONLINE && active
        Surface(
            color = if (online) Color(0xFF102D2D) else Color(0xFF2B2222),
            shape = RoundedCornerShape(13.dp),
            border = BorderStroke(1.dp, if (online) Color(0xFF28665D) else Color(0xFF6E4642))
        ) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(if (online) Color(0xFF56F0B1) else Color(0xFFFFB56D), CircleShape))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(if (online) "اتصال اینترنتی فعال" else if (!active) "در حال بازیابی اتصال اتاق…" else connectionStatus.labelFa, color = if (online) Color(0xFF9DF7D8) else Color(0xFFFFCF9A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(if (online) "پیام‌ها بین همه اعضای آنلاین همین حالا همگام می‌شوند." else "اینترنت و تنظیمات Firebase را بررسی کن؛ ارسال پیام تا اتصال دوباره ممکن نیست.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))

        if (members.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                members.take(8).forEach { member ->
                    Surface(color = Panel2, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, Border)) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(member.avatar, fontSize = 14.sp)
                            Spacer(Modifier.width(4.dp))
                            Text(member.name.take(10), color = TextMain, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        if (messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Box(Modifier.size(70.dp).background(Panel2, CircleShape).border(1.dp, Border, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Message, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(30.dp))
                    }
                    Text("اتاق آنلاین آماده است", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("اولین پیام را برای دوستانت بفرست.", color = TextMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                items(messages, key = { it.id }) { message -> MessageRow(message = message) }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp).background(Panel, RoundedCornerShape(19.dp)).border(1.dp, Border, RoundedCornerShape(19.dp)).padding(7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = draft,
                onValueChange = { draft = it.take(1000) },
                modifier = Modifier.weight(1f).padding(horizontal = 11.dp, vertical = 9.dp),
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextMain, fontSize = 14.sp),
                cursorBrush = SolidColor(NeonCyan),
                decorationBox = { inner ->
                    Box {
                        if (draft.isEmpty()) Text("پیام خود را بنویس...", color = TextMuted, fontSize = 13.sp)
                        inner()
                    }
                }
            )
            Button(
                onClick = {
                    val clean = draft.trim()
                    if (clean.isNotEmpty() && !sending) {
                        sending = true
                        scope.launch {
                            try {
                                FirebaseChatService.sendMessage(clean, profile)
                                draft = ""
                            } catch (e: Exception) {
                                Toast.makeText(context, FirebaseChatService.friendlyError(e), Toast.LENGTH_LONG).show()
                            } finally {
                                sending = false
                            }
                        }
                    }
                },
                enabled = draft.isNotBlank() && !sending,
                modifier = Modifier.size(45.dp),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Night, disabledContainerColor = Panel2, disabledContentColor = TextMuted)
            ) { Icon(Icons.Default.Send, contentDescription = "ارسال", modifier = Modifier.size(19.dp)) }
        }
        Text("پیام‌ها از طریق Firebase Realtime Database همگام می‌شوند.", color = TextMuted, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 3.dp))
    }
}

@Composable
private fun MessageRow(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isMine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!message.isMine) {
            Text(message.avatar, fontSize = 21.sp, modifier = Modifier.padding(end = 7.dp, bottom = 3.dp))
        }
        Column(horizontalAlignment = if (message.isMine) Alignment.End else Alignment.Start, modifier = Modifier.widthIn(max = 290.dp)) {
            if (!message.isMine) Text(message.senderName, color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 5.dp, bottom = 3.dp))
            Surface(
                color = if (message.isMine) Color(0xFF163B4B) else Panel2,
                shape = RoundedCornerShape(topStart = 15.dp, topEnd = 15.dp, bottomStart = if (message.isMine) 15.dp else 4.dp, bottomEnd = if (message.isMine) 4.dp else 15.dp),
                border = BorderStroke(1.dp, if (message.isMine) Color(0xFF286174) else Border)
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                    Text(message.body, color = TextMain, fontSize = 13.sp, lineHeight = 19.sp)
                    Text(formatTime(message.timestamp), color = TextMuted, fontSize = 9.sp, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
                }
            }
        }
        if (message.isMine) Text(message.avatar, fontSize = 21.sp, modifier = Modifier.padding(start = 7.dp, bottom = 3.dp))
    }
}

private fun formatTime(time: Long): String = runCatching {
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
}.getOrDefault("")

@Composable
private fun ProfileScreen(profile: UserProfile, onSave: (UserProfile) -> Unit, onCancel: () -> Unit) {
    var name by remember(profile.displayName) { mutableStateOf(profile.displayName) }
    var avatar by remember(profile.avatar) { mutableStateOf(profile.avatar.ifBlank { "👻" }) }
    var accent by remember(profile.accent) { mutableStateOf(profile.accent) }
    val avatars = listOf("👻", "🎮", "🐺", "👾", "🦊", "🐉", "⚡", "🦈", "🤖", "🌙", "🔥", "💎")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("پروفایل گیمر", color = TextMain, fontWeight = FontWeight.Black, fontSize = 26.sp)
        Text("اسمی انتخاب کن که دوستانت کنار پیام‌ها ببینند.", color = TextMuted, fontSize = 13.sp)
        Surface(color = Panel, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(88.dp).background(Brush.linearGradient(listOf(NeonCyan.copy(alpha = .2f), NeonPurple.copy(alpha = .25f))), CircleShape).border(1.dp, NeonCyan.copy(alpha = .6f), CircleShape), contentAlignment = Alignment.Center) {
                    Text(avatar, fontSize = 42.sp)
                }
                Text(name.ifBlank { "اسم تو" }, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("آواتار خودت را انتخاب کن", color = TextMuted, fontSize = 12.sp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    avatars.chunked(6).forEach { rowAvatars ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowAvatars.forEach { item ->
                                Surface(
                                    modifier = Modifier.size(43.dp).clickable { avatar = item },
                                    color = if (avatar == item) Color(0xFF184052) else Panel2,
                                    shape = RoundedCornerShape(13.dp),
                                    border = BorderStroke(1.dp, if (avatar == item) NeonCyan else Border)
                                ) { Box(contentAlignment = Alignment.Center) { Text(item, fontSize = 22.sp) } }
                            }
                        }
                    }
                }
            }
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(24) },
            label = { Text("نام نمایشی") },
            supportingText = { Text("حداکثر ۲۴ نویسه • بدون نیاز به شماره تلفن") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = NeonCyan) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedLabelColor = NeonCyan, unfocusedBorderColor = Border, focusedTextColor = TextMain, unfocusedTextColor = TextMain)
        )
        Text("رنگ نمایشی", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            listOf("cyan" to NeonCyan, "purple" to NeonPurple, "pink" to NeonPink, "blue" to NeonBlue).forEach { (id, color) ->
                Surface(
                    modifier = Modifier.size(45.dp).clickable { accent = id },
                    shape = CircleShape,
                    color = color,
                    border = BorderStroke(if (accent == id) 3.dp else 1.dp, if (accent == id) TextMain else color.copy(alpha = .6f))
                ) { if (accent == id) Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CheckCircle, contentDescription = "انتخاب شده", tint = Night) } }
            }
        }
        Button(onClick = { onSave(UserProfile(name.trim().ifBlank { "Shadow" }, avatar, accent)) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Night)) {
            Text("ذخیره پروفایل", fontWeight = FontWeight.Black)
        }
        TextButton(onClick = onCancel, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("بازگشت", color = TextMuted) }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun FirebaseConfigDialog(
    initialConfig: FirebaseProjectConfig?,
    initialError: String,
    busy: Boolean,
    onDismiss: () -> Unit,
    onShareConfig: (String) -> Unit,
    onSave: (FirebaseProjectConfig) -> Unit
) {
    var apiKey by remember { mutableStateOf(initialConfig?.apiKey.orEmpty()) }
    var appId by remember { mutableStateOf(initialConfig?.appId.orEmpty()) }
    var projectId by remember { mutableStateOf(initialConfig?.projectId.orEmpty()) }
    var databaseUrl by remember { mutableStateOf(initialConfig?.databaseUrl.orEmpty()) }
    var senderId by remember { mutableStateOf(initialConfig?.senderId.orEmpty()) }
    var importCode by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf("") }
    val candidate = FirebaseProjectConfig(apiKey, appId, projectId, databaseUrl, senderId)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("راه‌اندازی چت اینترنتی", color = TextMain, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Text(
                    "این برنامه برای هماهنگ شدن گوشی‌ها به یک پروژه مشترک Firebase نیاز دارد؛ سرور اختصاصی خودت را مدیریت نمی‌کنی. سازنده اتاق می‌تواند پس از یک‌بار تنظیم، کد زیر را برای دوستان بفرستد.",
                    color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp
                )
                Text("راه سریع: کد تنظیمات را از دوستت بگیر و اینجا وارد کن.", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = importCode,
                    onValueChange = { importCode = it.trim() },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("کد تنظیمات GC1:…") },
                    minLines = 2,
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedLabelColor = NeonCyan, unfocusedBorderColor = Border, focusedTextColor = TextMain, unfocusedTextColor = TextMain)
                )
                TextButton(
                    enabled = importCode.isNotBlank() && !busy,
                    onClick = {
                        val imported = FirebaseProjectConfig.fromShareCode(importCode)
                        if (imported == null) localError = "کد تنظیمات معتبر نیست؛ کل متن GC1:… را کپی کن."
                        else {
                            apiKey = imported.apiKey
                            appId = imported.appId
                            projectId = imported.projectId
                            databaseUrl = imported.databaseUrl
                            senderId = imported.senderId
                            localError = "تنظیمات دوستت وارد شد؛ حالا ذخیره و اتصال را آزمایش کن."
                        }
                    }
                ) { Text("وارد کردن کد تنظیمات", color = NeonCyan) }
                Divider(color = Border)
                Text("یا مشخصات Firebase را دستی وارد کن", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("مقادیر از google-services.json می‌آیند: current_key، mobilesdk_app_id، project_id، project_number و firebase_url. آدرس دیتابیس را از Realtime Database هم می‌توانی برداری.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                ConfigTextField("Web API Key / current_key", apiKey, { apiKey = it }, singleLine = true)
                ConfigTextField("Firebase App ID / mobilesdk_app_id", appId, { appId = it }, singleLine = true)
                ConfigTextField("Project ID / project_id", projectId, { projectId = it }, singleLine = true)
                ConfigTextField("Realtime Database URL", databaseUrl, { databaseUrl = it }, singleLine = true)
                ConfigTextField("Sender ID / project_number", senderId, { senderId = it }, singleLine = true)
                if (localError.isNotBlank()) Text(localError, color = if (candidate.isValid()) NeonCyan else NeonPink, fontSize = 11.sp, lineHeight = 15.sp)
                if (initialError.isNotBlank()) Text(initialError, color = NeonPink, fontSize = 11.sp, lineHeight = 15.sp)
                if (busy) Text("در حال ورود ناشناس و آزمایش اتصال به Firebase…", color = NeonCyan, fontSize = 12.sp)
                if (candidate.isValid() && !busy) {
                    TextButton(onClick = { onShareConfig(candidate.toShareCode()) }) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = NeonPurple)
                        Spacer(Modifier.width(7.dp))
                        Text("اشتراک تنظیمات با دوستان", color = NeonPurple)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = candidate.isValid() && !busy, onClick = { onSave(candidate) }) {
                Text(if (busy) "در حال اتصال…" else "ذخیره و تست اتصال", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("بستن", color = TextMuted) } }
    )
}

@Composable
private fun ConfigTextField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label, fontSize = 11.sp) },
        singleLine = singleLine,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, focusedLabelColor = NeonCyan, unfocusedBorderColor = Border, focusedTextColor = TextMain, unfocusedTextColor = TextMain)
    )
}

@Composable
private fun SettingsScreen(
    onLaunchOverlay: () -> Unit,
    onRequestAppLockChange: (Boolean) -> Unit,
    animationsEnabled: Boolean,
    onAnimationsChanged: (Boolean) -> Unit,
    connectionStatus: ConnectionStatus,
    configured: Boolean,
    onConnectionSettings: () -> Unit,
    onShareFirebaseConfig: () -> Unit
) {
    var vibration by remember { mutableStateOf(ChatPrefs.vibrationEnabled()) }
    var compact by remember { mutableStateOf(ChatPrefs.compactOverlay()) }
    val appLockEnabled by ChatPrefs.appLockFlow.collectAsState()
    var showReset by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("تنظیمات", color = TextMain, fontWeight = FontWeight.Black, fontSize = 27.sp)
        Text("نسخه ۱.۰.۰ · ساخت 1 · ظاهر، امنیت و اتصال را مدیریت کن.", color = TextMuted, fontSize = 13.sp)
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Border)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WifiOff, contentDescription = null, tint = if (connectionStatus == ConnectionStatus.ONLINE) Color(0xFF56F0B1) else Color(0xFFFFB56D))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("اتصال اینترنتی", color = TextMain, fontWeight = FontWeight.Bold)
                        Text(if (configured) connectionStatus.labelFa else "هنوز پیکربندی نشده", color = TextMuted, fontSize = 11.sp)
                    }
                }
                Text("همه اعضای گروه باید همین پروژه Firebase را تنظیم کنند. با کد اشتراک، لازم نیست هر دوست مشخصات را دستی بنویسد.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                Button(onClick = onConnectionSettings, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF35204F), contentColor = NeonCyan)) {
                    Text(if (configured) "تغییر / آزمایش اتصال" else "تنظیم اتصال اینترنت", fontWeight = FontWeight.Bold)
                }
                if (configured) TextButton(onClick = onShareFirebaseConfig) { Text("اشتراک کد تنظیمات با دوستان", color = NeonPurple) }
            }
        }
        Surface(
            color = Color(0xFF18122B),
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.6f))
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = NeonPurple)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                        Text("قفل و امنیت برنامه", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("اثر انگشت یا PIN / الگو / گذرواژهٔ گوشی", color = TextMuted, fontSize = 11.sp)
                    }
                }
                Divider(color = Border)
                SettingSwitch(
                    "قفل برنامه با اثر انگشت",
                    if (appLockEnabled) "فعال است؛ با خروج، صفحه و محتوای حباب پنهان و اسکرین‌شات مسدود می‌شود." else "برای ورود دوباره، تأیید هویت گوشی لازم می‌شود.",
                    appLockEnabled,
                    onRequestAppLockChange
                )
                Text(
                    if (ChatPrefs.isLocalStorageEncrypted()) "حافظه محلی: رمزنگاری‌شده با Android Keystore" else "هشدار: رمزنگاری محلی در این دستگاه در دسترس نیست.",
                    color = if (ChatPrefs.isLocalStorageEncrypted()) Color(0xFF6FE6B5) else Color(0xFFFFB56D),
                    fontSize = 10.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Border)) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                SettingSwitch("انیمیشن‌های نرم", "تغییر صفحه‌ها با حرکت کوتاه", animationsEnabled) {
                    ChatPrefs.setAnimationsEnabled(it)
                    onAnimationsChanged(it)
                }
                Divider(color = Border)
                SettingSwitch("لرزش هنگام لمس", "بازخورد لمسی سبک روی حباب", vibration) {
                    vibration = it; ChatPrefs.setVibrationEnabled(it)
                }
                Divider(color = Border)
                SettingSwitch("حباب فشرده", "اندازه کوچک‌تر هنگام بازی", compact) {
                    compact = it; ChatPrefs.setCompactOverlay(it)
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Border)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Message, contentDescription = null, tint = NeonCyan)
                    Spacer(Modifier.width(10.dp))
                    Text("پنجره شناور", color = TextMain, fontWeight = FontWeight.Bold)
                }
                Text("اندروید برای نمایش روی بازی باید اجازهٔ «نمایش روی برنامه‌های دیگر» را داشته باشد.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                Button(onClick = onLaunchOverlay, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF35204F), contentColor = NeonCyan)) {
                    Text("بررسی مجوز و اجرای حباب", fontWeight = FontWeight.Bold)
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Border)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("حریم خصوصی و وضعیت", color = TextMain, fontWeight = FontWeight.Bold)
                Text("• ورود ناشناس Firebase و قواعد سمت سرور برای محدودکردن دسترسی اتاق‌ها استفاده می‌شوند.\n• در صورت پشتیبانی دستگاه، تنظیمات و کش پیام محلی با Android Keystore رمزنگاری می‌شود؛ پشتیبان‌گیری اندروید خاموش است.\n• قفل برنامه صفحه را پس از خروج قفل می‌کند و ثبت اسکرین‌شات را می‌بندد. این قفل جایگزین امنیت حساب/سرور نیست و رمزنگاری سرتاسری (E2E) فراهم نمی‌کند.\n• برای انتشار عمومی هنوز باید Firebase App Check، کنترل سوءاستفاده، سیاست حریم خصوصی و پاک‌سازی خودکار اتاق‌ها تنظیم شوند.", color = TextMuted, fontSize = 12.sp, lineHeight = 19.sp)
                TextButton(onClick = { showReset = true }) { Text("پاک کردن تاریخچه محلی", color = NeonPink) }
            }
        }
        Spacer(Modifier.height(12.dp))
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            containerColor = Panel,
            title = { Text("پاک کردن پیام‌ها؟", color = TextMain, fontWeight = FontWeight.Bold) },
            text = { Text("پیام‌های ذخیره‌شده در همین گوشی پاک می‌شوند.", color = TextMuted) },
            confirmButton = {
                TextButton(onClick = {
                    ChatPrefs.clearAllMessages()
                    showReset = false
                }) { Text("پاک کن", color = NeonPink) }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("لغو", color = TextMuted) } }
        )
    }
}

@Composable
private fun SettingSwitch(title: String, description: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(description, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun BottomNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Surface(color = Color(0xF20E1220), border = BorderStroke(1.dp, Color(0xFF202A40))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            NavItem("خانه", Icons.Default.Home, selected == Tab.HOME) { onSelect(Tab.HOME) }
            NavItem("چت", Icons.Default.Message, selected == Tab.CHAT) { onSelect(Tab.CHAT) }
            NavItem("پروفایل", Icons.Default.Person, selected == Tab.PROFILE) { onSelect(Tab.PROFILE) }
            NavItem("تنظیمات", Icons.Default.Settings, selected == Tab.SETTINGS) { onSelect(Tab.SETTINGS) }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).background(if (selected) Color(0xFF3A205D) else Color.Transparent).padding(horizontal = 12.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) NeonCyan else TextMuted, modifier = Modifier.size(20.dp))
        Text(label, color = if (selected) NeonCyan else TextMuted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}
