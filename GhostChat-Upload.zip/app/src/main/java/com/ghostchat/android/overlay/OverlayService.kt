package com.ghostchat.android.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ServiceCompat
import com.ghostchat.android.MainActivity
import com.ghostchat.android.data.ChatMessage
import com.ghostchat.android.data.ChatPrefs
import com.ghostchat.android.data.UserProfile
import com.ghostchat.android.R
import com.ghostchat.android.network.FirebaseChatService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Floating Android overlay. It shares the same Firebase-backed live room as the main screen. */
class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var panelMessages: LinearLayout? = null
    private var messageInput: EditText? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var isExpanded = false
    private var isLockPanel = false
    private var unreadBadge: View? = null
    private var visibleRoomInOverlay: String? = null
    private var connectionText: TextView? = null
    private var sending = false
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        ChatPrefs.init(applicationContext)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        ChatPrefs.firebaseConfig()?.let { config ->
            runCatching { FirebaseChatService.configure(applicationContext, config) }
            serviceScope.launch {
                runCatching {
                    FirebaseChatService.connectAndSignIn()
                    val room = ChatPrefs.roomCode()
                    if (room.isNotBlank()) FirebaseChatService.joinRoom(room, ChatPrefs.profile())
                }
            }
        }
        serviceScope.launch {
            ChatPrefs.messagesFlow.collect {
                renderMessages()
                refreshBubbleBadge()
            }
        }
        serviceScope.launch {
            FirebaseChatService.connectionStatus.collect { status ->
                connectionText?.text = status.labelFa
            }
        }
        serviceScope.launch {
            ChatPrefs.appSurfaceLockedFlow.collect { locked ->
                if (ChatPrefs.appLockEnabled() && locked) {
                    if (isExpanded) showLockPanel()
                } else if (isLockPanel) {
                    // Do not reveal chat messages automatically as soon as authentication succeeds.
                    showBubble()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startOverlayForeground()
        if (bubbleView == null && panelView == null) showBubble()
        return START_STICKY
    }

    private fun startOverlayForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Ghost Chat overlay", NotificationManager.IMPORTANCE_LOW).apply {
                description = "کنترل حباب شناور Ghost Chat"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Ghost Chat فعال است")
            .setContentText("حباب شناور چت آنلاین آماده است")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun showBubble() {
        removePanel()
        isExpanded = false
        isLockPanel = false
        val bubbleSize = dp(if (ChatPrefs.compactOverlay()) 48 else 58)
        val root = FrameLayout(this).apply {
            background = roundedDrawable(intArrayOf(0xFF21103D.toInt(), 0xFF24143E.toInt()), 0xFF9C62FA.toInt(), 100f)
            elevation = dp(12).toFloat()
            clipChildren = false
            clipToPadding = false
        }
        val face = TextView(this).apply {
            text = "👻"
            textSize = if (ChatPrefs.compactOverlay()) 24f else 29f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(face, FrameLayout.LayoutParams(-1, -1))


        val params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(10)
            y = resources.displayMetrics.heightPixels / 3
        }

        var downX = 0f
        var downY = 0f
        var originX = params.x
        var originY = params.y
        var didMove = false
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    originX = params.x
                    originY = params.y
                    didMove = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) didMove = true
                    params.x = originX + dx.toInt()
                    params.y = originY + dy.toInt()
                    runCatching { windowManager.updateViewLayout(root, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!didMove) {
                        if (ChatPrefs.vibrationEnabled()) root.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                        showPanel()
                    }
                    true
                }
                else -> true
            }
        }

        runCatching { windowManager.addView(root, params) }
            .onSuccess {
                bubbleView = root
                bubbleParams = params
                refreshBubbleBadge()
            }
            .onFailure { stopSelf() }
    }

    private fun showPanel() {
        if (ChatPrefs.appLockEnabled() && ChatPrefs.isAppSurfaceLocked()) {
            showLockPanel()
            return
        }
        if (isExpanded) return
        isLockPanel = false
        removeBubble()
        isExpanded = true
        visibleRoomInOverlay = ChatPrefs.roomCode().takeIf { it.isNotBlank() }
        visibleRoomInOverlay?.let { ChatPrefs.setRoomVisible("floating-overlay", it, true) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = roundedDrawable(intArrayOf(0xF20D1424.toInt(), 0xF21A1530.toInt()), 0xFF344568.toInt(), 24f)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            elevation = dp(18).toFloat()
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(TextView(this).apply {
            text = "GHOST CHAT"
            textSize = 14f
            setTextColor(0xFFF4F7FF.toInt())
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            letterSpacing = .12f
        })
        connectionText = TextView(this).apply {
            text = FirebaseChatService.connectionStatus.value.labelFa
            textSize = 10f
            setTextColor(0xFF9CA8C3.toInt())
        }
        heading.addView(connectionText)
        top.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chromeButton("−", 0xFF1C2941.toInt()) { showBubble() })
        top.addView(chromeButton("×", 0xFF3D1C3A.toInt()) { stopSelf() }, LinearLayout.LayoutParams(dp(40), dp(38)).apply { leftMargin = dp(5) })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))
        root.addView(separator())

        val scroll = ScrollView(this).apply { fillViewport = true }
        val messageColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(6), dp(2), dp(8))
        }
        scroll.addView(messageColumn, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(2); bottomMargin = dp(8) })
        panelMessages = messageColumn

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedDrawable(intArrayOf(0xFF161D2E.toInt(), 0xFF161D2E.toInt()), 0xFF33405C.toInt(), 16f)
            setPadding(dp(7), dp(5), dp(5), dp(5))
        }
        val edit = EditText(this).apply {
            hint = "پیام را بنویس..."
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setHintTextColor(0xFF8996B0.toInt())
            setTextColor(0xFFF4F7FF.toInt())
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = null
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        messageInput = edit
        val send = chromeButton("➤", 0xFF28DDF5.toInt()) { sendOverlayMessage() }.apply { setTextColor(0xFF08101B.toInt()) }
        inputRow.addView(edit, LinearLayout.LayoutParams(0, dp(43), 1f))
        inputRow.addView(send, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(inputRow, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "پیام‌ها با اعضای آنلاین اتاق همگام می‌شوند."
            textSize = 9f
            setTextColor(0xFF9CA8C3.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))

        edit.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendOverlayMessage(); true
            } else false
        }
        renderMessages()

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val compact = ChatPrefs.compactOverlay()
        val params = WindowManager.LayoutParams(
            (screenWidth * if (compact) .82f else .93f).toInt(),
            (screenHeight * if (compact) .42f else .53f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = screenHeight / 5
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        runCatching { windowManager.addView(root, params) }
            .onSuccess {
                panelView = root
                panelParams = params
            }
            .onFailure {
                isExpanded = false
                showBubble()
            }
    }

    private fun showLockPanel() {
        if (isLockPanel && panelView != null) return
        removePanel()
        removeBubble()
        isExpanded = true
        isLockPanel = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = roundedDrawable(intArrayOf(0xF2191031.toInt(), 0xF20D1020.toInt()), 0xFF8E52E8.toInt(), 24f)
            setPadding(dp(20), dp(22), dp(20), dp(22))
            elevation = dp(18).toFloat()
        }
        root.addView(TextView(this).apply {
            text = "👻  GHOST CHAT"
            textSize = 17f
            setTextColor(0xFFF4F0FF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "برنامه قفل است؛ پیام‌ها پنهان شده‌اند.\nبرای دیدن گفتگوها، برنامه را باز و هویتت را تأیید کن."
            textSize = 13f
            setTextColor(0xFFC7BEDF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(14))
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(chromeButton("باز کردن برنامه", 0xFF8D4DDB.toInt()) {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            runCatching { startActivity(intent) }
        }, LinearLayout.LayoutParams(-1, dp(46)))
        root.addView(chromeButton("بستن حباب", 0xFF31243E.toInt()) { stopSelf() }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(8) })

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val params = WindowManager.LayoutParams(
            (screenWidth * .84f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = screenHeight / 4
        }
        runCatching { windowManager.addView(root, params) }
            .onSuccess {
                panelView = root
                panelParams = params
            }
            .onFailure {
                isExpanded = false
                isLockPanel = false
                showBubble()
            }
    }

    private fun sendOverlayMessage() {
        if (ChatPrefs.appLockEnabled() && ChatPrefs.isAppSurfaceLocked()) {
            showLockPanel()
            return
        }
        val edit = messageInput ?: return
        val text = edit.text?.toString()?.trim().orEmpty()
        if (text.isEmpty() || sending) return
        if (ChatPrefs.roomCode().isBlank()) {
            Toast.makeText(this, "ابتدا از صفحه اصلی یک اتاق آنلاین بساز یا وارد اتاق شو.", Toast.LENGTH_LONG).show()
            return
        }
        sending = true
        serviceScope.launch {
            try {
                FirebaseChatService.sendMessage(text, ChatPrefs.profile())
                if (messageInput === edit) edit.setText("")
            } catch (e: Exception) {
                Toast.makeText(this@OverlayService, FirebaseChatService.friendlyError(e), Toast.LENGTH_LONG).show()
            } finally {
                sending = false
            }
        }
    }

    private fun renderMessages() {
        if (ChatPrefs.appLockEnabled() && ChatPrefs.isAppSurfaceLocked()) {
            if (isExpanded) showLockPanel()
            return
        }
        val column = panelMessages ?: return
        column.removeAllViews()
        val room = ChatPrefs.roomCode()
        val messages = if (room.isBlank()) emptyList() else ChatPrefs.messagesForRoom(room).takeLast(16)
        if (messages.isEmpty()) {
            column.addView(TextView(this).apply {
                text = if (room.isBlank()) "هنوز اتاق آنلاینی انتخاب نشده.\nبرنامه را باز کن و یک اتاق بساز یا با کد وارد شو." else "اتاق آماده است.\nاولین پیام را برای دوستانت بفرست."
                textSize = 13f
                setTextColor(0xFFACB7CC.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(18), dp(10), dp(18))
            }, LinearLayout.LayoutParams(-1, -2))
        } else {
            messages.forEach { message ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = if (message.isMine) Gravity.END else Gravity.START
                    setPadding(dp(2), dp(3), dp(2), dp(3))
                }
                val bubble = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = roundedDrawable(
                        intArrayOf(if (message.isMine) 0xFF30204C.toInt() else 0xFF1B1930.toInt(), if (message.isMine) 0xFF30204C.toInt() else 0xFF1B1930.toInt()),
                        if (message.isMine) 0xFF7656A8.toInt() else 0xFF45345F.toInt(),
                        15f
                    )
                    setPadding(dp(11), dp(8), dp(11), dp(8))
                }
                bubble.addView(TextView(this).apply {
                    text = if (message.isMine) "${message.avatar} ${message.senderName}" else "${message.avatar} ${message.senderName}"
                    textSize = 10f
                    setTextColor(0xFFB36BFF.toInt())
                    typeface = Typeface.DEFAULT_BOLD
                })
                bubble.addView(TextView(this).apply {
                    text = message.body
                    textSize = 13f
                    setTextColor(0xFFF4F7FF.toInt())
                    setPadding(0, dp(3), 0, 0)
                })
                bubble.addView(TextView(this).apply {
                    text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
                    textSize = 9f
                    setTextColor(0xFF9CA8C3.toInt())
                    gravity = Gravity.END
                    setPadding(0, dp(3), 0, 0)
                })
                row.addView(bubble, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(2); rightMargin = dp(2) })
                column.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }

    private fun chromeButton(text: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 20f
        gravity = Gravity.CENTER
        setTextColor(if (color == 0xFF28DDF5.toInt()) 0xFF08101B.toInt() else 0xFFF4F7FF.toInt())
        background = roundedDrawable(intArrayOf(color, color), color, 13f)
        setOnClickListener { action() }
    }

    private fun separator(): View = View(this).apply {
        setBackgroundColor(0xFF2B3651.toInt())
    }.also { it.layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(9); bottomMargin = dp(8) } }

    private fun roundedDrawable(colors: IntArray, stroke: Int, radiusDp: Float): GradientDrawable = GradientDrawable(
        if (colors.size > 1) GradientDrawable.Orientation.TL_BR else GradientDrawable.Orientation.LEFT_RIGHT,
        colors
    ).apply {
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun refreshBubbleBadge() {
        val root = bubbleView as? FrameLayout ?: return
        val room = ChatPrefs.roomCode()
        val shouldShow = room.isNotBlank() && ChatPrefs.unreadCount(room) > 0
        if (shouldShow && unreadBadge == null) {
            val badge = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFFFF426F.toInt())
                    setStroke(dp(2), 0xFF101522.toInt())
                }
                contentDescription = "پیام خوانده‌نشده"
            }
            root.addView(badge, FrameLayout.LayoutParams(dp(13), dp(13), Gravity.TOP or Gravity.END))
            unreadBadge = badge
        } else if (!shouldShow && unreadBadge != null) {
            runCatching { root.removeView(unreadBadge) }
            unreadBadge = null
        }
    }

    private fun removeBubble() {
        bubbleView?.let { view -> runCatching { windowManager.removeView(view) } }
        bubbleView = null
        bubbleParams = null
        unreadBadge = null
    }

    private fun removePanel() {
        panelView?.let { view -> runCatching { windowManager.removeView(view) } }
        panelView = null
        panelParams = null
        panelMessages = null
        messageInput = null
        connectionText = null
        visibleRoomInOverlay?.let { ChatPrefs.setRoomVisible("floating-overlay", it, false) }
        visibleRoomInOverlay = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    override fun onDestroy() {
        removePanel()
        removeBubble()
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "ghost_chat_overlay"
        private const val NOTIFICATION_ID = 7421
    }
}
