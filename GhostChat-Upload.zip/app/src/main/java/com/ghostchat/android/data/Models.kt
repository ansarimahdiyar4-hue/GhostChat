package com.ghostchat.android.data

data class UserProfile(
    val displayName: String = "Shadow",
    val avatar: String = "👻",
    val accent: String = "cyan"
)

data class ChatMessage(
    val id: String,
    val roomCode: String,
    val senderId: String,
    val senderName: String,
    val avatar: String,
    val body: String,
    val timestamp: Long,
    val isMine: Boolean,
    val isUnread: Boolean = false
)
