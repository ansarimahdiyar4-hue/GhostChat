package com.ghostchat.android.network

import android.content.Context
import com.ghostchat.android.data.ChatMessage
import com.ghostchat.android.data.ChatPrefs
import com.ghostchat.android.data.FirebaseProjectConfig
import com.ghostchat.android.data.UserProfile
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.Query
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.io.IOException
import java.security.SecureRandom

/**
 * Realtime group chat transport. Firebase Realtime Database is the shared rendezvous/message
 * service: the app does not operate or require a self-managed server. All members must configure
 * the same Firebase project. The Firebase client API key is not an admin secret; database rules
 * are essential and are supplied in /firebase/database.rules.json.
 */
object FirebaseChatService {
    private const val APP_NAME = "GhostChatRealtime"
    private const val MAX_MEMBERS = 8
    private const val MAX_MESSAGES = 100
    private const val ROOM_TTL_MS = 24L * 60L * 60L * 1000L
    private const val ROOM_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    enum class ConnectionStatus(val labelFa: String) {
        UNCONFIGURED("تنظیم اتصال اینترنت لازم است"),
        CONNECTING("در حال اتصال به اینترنت…"),
        ONLINE("متصل به اینترنت"),
        OFFLINE("ارتباط اینترنتی قطع است")
    }

    data class RoomMember(
        val uid: String,
        val name: String,
        val avatar: String,
        val joinedAt: Long,
        val slot: Int
    )

    private val random = SecureRandom()
    private val authMutex = Mutex()
    private val roomMutex = Mutex()
    private val networkScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutableConnectionStatus = MutableStateFlow(ConnectionStatus.UNCONFIGURED)
    private val mutableMembers = MutableStateFlow<List<RoomMember>>(emptyList())
    val connectionStatus: StateFlow<ConnectionStatus> = mutableConnectionStatus.asStateFlow()
    val members: StateFlow<List<RoomMember>> = mutableMembers.asStateFlow()

    @Volatile private var activeConfig: FirebaseProjectConfig? = null
    @Volatile private var firebaseApp: FirebaseApp? = null
    @Volatile private var auth: FirebaseAuth? = null
    @Volatile private var database: FirebaseDatabase? = null
    private var connectedRef: DatabaseReference? = null
    private var connectedListener: ValueEventListener? = null
    @Volatile private var currentUid: String? = null
    @Volatile private var currentRoom: String? = null
    @Volatile private var currentSlot: Int? = null
    @Volatile private var currentSlotRef: DatabaseReference? = null
    private var memberRef: DatabaseReference? = null
    private var memberListener: ValueEventListener? = null
    private var messageQuery: Query? = null
    private var messageListener: ChildEventListener? = null

    @Synchronized
    fun configure(context: Context, config: FirebaseProjectConfig) {
        require(config.isValid()) { "تنظیمات Firebase کامل نیست؛ فیلدها را بررسی کن." }
        if (activeConfig == config && database != null && auth != null) return

        detachRoomListeners()
        connectedRef?.let { ref -> connectedListener?.let(ref::removeEventListener) }
        connectedRef = null
        connectedListener = null
        database = null
        auth = null
        firebaseApp = null
        currentUid = null
        currentRoom = null
        currentSlot = null
        currentSlotRef = null
        mutableMembers.value = emptyList()

        val appContext = context.applicationContext
        FirebaseApp.getApps(appContext).filter { it.name == APP_NAME }.forEach { old ->
            runCatching { old.delete() }
        }
        val options = FirebaseOptions.Builder()
            .setApiKey(config.apiKey.trim())
            .setApplicationId(config.appId.trim())
            .setProjectId(config.projectId.trim())
            .setDatabaseUrl(config.databaseUrl.trim().trimEnd('/'))
            .setGcmSenderId(config.senderId.trim())
            .build()
        val app = FirebaseApp.initializeApp(appContext, options, APP_NAME)
        val db = FirebaseDatabase.getInstance(app, config.databaseUrl.trim().trimEnd('/'))
        val firebaseAuth = FirebaseAuth.getInstance(app)
        firebaseApp = app
        database = db
        auth = firebaseAuth
        activeConfig = config
        mutableConnectionStatus.value = ConnectionStatus.CONNECTING

        val info = db.getReference(".info/connected")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val isConnected = snapshot.getValue(Boolean::class.java) == true
                mutableConnectionStatus.value = when {
                    isConnected -> ConnectionStatus.ONLINE
                    auth == null -> ConnectionStatus.UNCONFIGURED
                    else -> ConnectionStatus.OFFLINE
                }
                // RTDB executes the previously registered onDisconnect actions when a socket
                // drops. Reclaim this client's slot and re-register cleanup after reconnect.
                // A mutex inside joinRoom serializes this with sends/profile updates/room changes.
                if (isConnected && currentRoom != null && currentUid != null) {
                    val roomToRestore = currentRoom
                    networkScope.launch {
                        if (roomToRestore.isNullOrBlank()) return@launch
                        runCatching {
                            roomMutex.withLock {
                                // The user may have switched rooms before this reconnect task gets
                                // the lock. Never resurrect a stale room over their newer choice.
                                if (currentRoom == roomToRestore) {
                                    joinRoomInternal(roomToRestore, ChatPrefs.profile())
                                }
                            }
                        }.onFailure {
                            // The database socket may still be online while a rule rejects a
                            // membership refresh. Leave socket status intact; sends surface errors.
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {
                mutableConnectionStatus.value = ConnectionStatus.OFFLINE
            }
        }
        connectedRef = info
        connectedListener = listener
        info.addValueEventListener(listener)
    }

    fun isConfigured(): Boolean = activeConfig?.isValid() == true && database != null && auth != null

    suspend fun connectAndSignIn(context: Context? = null, config: FirebaseProjectConfig? = null): String {
        if (config != null) {
            requireNotNull(context) { "Context is required to configure Firebase." }
            configure(context, config)
        }
        return authMutex.withLock {
            val firebaseAuth = auth ?: throw IllegalStateException("ابتدا تنظیمات Firebase را وارد کن.")
            try {
                val user = firebaseAuth.currentUser ?: firebaseAuth.signInAnonymously().await().user
                    ?: throw IOException("ورود ناشناس Firebase موفق نبود.")
                currentUid = user.uid
                // A successful Auth response alone does not prove that Realtime Database is live.
                // Wait for the database socket too; otherwise the UI might claim a connection
                // before room creation or message sends can actually succeed.
                if (mutableConnectionStatus.value != ConnectionStatus.ONLINE) {
                    withTimeout(15_000L) {
                        connectionStatus.first { it == ConnectionStatus.ONLINE }
                    }
                }
                // Probe a harmless, non-existing path. This confirms that the app can actually
                // read the configured RTDB under the supplied security rules, not merely that an
                // Auth token or TCP socket exists. No data is written by this probe.
                val db = database ?: throw IOException("Realtime Database مقداردهی نشده است.")
                db.getReference("rooms").child("__ghostchat_access_probe__").child("meta").get().await()
                user.uid
            } catch (e: Exception) {
                // Keep socket status separate from auth/rules errors. If the database socket is
                // already ONLINE but auth/rules are wrong, a user must be able to fix rules and
                // retry without having to disconnect the entire socket first.
                if (mutableConnectionStatus.value != ConnectionStatus.ONLINE) {
                    mutableConnectionStatus.value = ConnectionStatus.OFFLINE
                }
                throw IOException(friendlyError(e), e)
            }
        }
    }

    suspend fun createRoom(profile: UserProfile): String {
        val uid = connectAndSignIn()
        val db = database ?: throw IllegalStateException("Firebase آماده نیست.")
        var lastFailure: Exception? = null
        repeat(12) {
            val code = generateRoomCode()
            val metaRef = db.getReference("rooms").child(code).child("meta")
            val meta = mapOf(
                "createdByUid" to uid,
                "createdAt" to System.currentTimeMillis(),
                "schemaVersion" to 1
            )
            try {
                metaRef.setValue(meta).await()
            } catch (e: Exception) {
                val exists = runCatching { metaRef.get().await().exists() }.getOrDefault(false)
                if (exists) {
                    lastFailure = e
                    return@repeat
                }
                throw IOException(friendlyError(e), e)
            }
            try {
                joinRoom(code, profile)
                return code
            } catch (e: Exception) {
                runCatching { metaRef.removeValue().await() }
                throw e
            }
        }
        throw IOException(lastFailure?.let(::friendlyError) ?: "فعلاً کد اتاق ساخته نشد. دوباره امتحان کن.")
    }

    suspend fun joinRoom(rawCode: String, profile: UserProfile): String = roomMutex.withLock {
        joinRoomInternal(rawCode, profile)
    }

    private suspend fun joinRoomInternal(rawCode: String, profile: UserProfile): String {
        val code = rawCode.trim().uppercase().filter { it.isLetterOrDigit() }
        if (code.length != 8) throw IOException("کد اتاق باید ۸ نویسه باشد.")
        val uid = connectAndSignIn()
        val db = database ?: throw IllegalStateException("Firebase آماده نیست.")

        if (currentRoom == code && currentUid == uid && currentSlot != null) {
            val slot = currentSlotRef ?: db.getReference("rooms").child(code).child("slots").child(currentSlot.toString())
            // Refresh the slot first (it may have been removed by a prior onDisconnect), then
            // register a server-side cleanup action for the next disconnect.
            slot.setValue(memberPayload(uid, profile)).await()
            slot.onDisconnect().removeValue().await()
            attachRoomListeners(code, uid)
            return code
        }
        if (currentRoom != null) leaveCurrentRoom()

        val roomRef = db.getReference("rooms").child(code)
        val meta = roomRef.child("meta").get().await()
        if (!meta.exists()) throw IOException("اتاقی با این کد پیدا نشد؛ کد را بررسی کن.")
        val createdAt = meta.child("createdAt").getValue(Long::class.java) ?: 0L
        if (createdAt > 0L && System.currentTimeMillis() - createdAt > ROOM_TTL_MS) {
            throw IOException("عمر این اتاق تمام شده است. از سازنده بخواه اتاق تازه بسازد.")
        }

        // Claim a slot by attempting a write instead of reading the whole slots node first.
        // This enables membership-only read rules: a stranger with an invite code cannot inspect
        // member names/UIDs before joining. The per-slot server rule atomically rejects occupied
        // slots and duplicate UIDs, so a racing phone simply tries the next slot. Existing members
        // can refresh their own slot because the rule permits a write when data.uid == auth.uid.
        var claimedSlot: Int? = null
        var lastSlotError: Exception? = null
        for (slotIndex in 0 until MAX_MEMBERS) {
            val slotRef = roomRef.child("slots").child(slotIndex.toString())
            try {
                slotRef.setValue(memberPayload(uid, profile)).await()
                claimedSlot = slotIndex
                break
            } catch (e: Exception) {
                // Another user may have claimed this slot, or the server rules may reject it.
                // Continue because the next slot could be free; retain the final error for support.
                lastSlotError = e
            }
        }
        if (claimedSlot == null) {
            // Recover from the rare case where Firebase committed a slot write but the client did
            // not receive its acknowledgement. A successful read here is also proof that the UID
            // now belongs to the room under the membership-only read rule.
            val recovered = runCatching { roomRef.child("slots").get().await() }.getOrNull()
                ?.children
                ?.firstOrNull { it.child("uid").getValue(String::class.java) == uid }
                ?.key
                ?.toIntOrNull()
            if (recovered != null) {
                val retry = runCatching {
                    roomRef.child("slots").child(recovered.toString())
                        .setValue(memberPayload(uid, profile)).await()
                }
                if (retry.isSuccess) {
                    claimedSlot = recovered
                } else {
                    val retryError = retry.exceptionOrNull()
                    if (retryError is Exception) lastSlotError = retryError
                }
            }
        }
        if (claimedSlot == null) {
            val detail = lastSlotError?.let(::friendlyError)
            val suffix = detail?.takeIf { it.isNotBlank() }
            throw IOException(
                if (suffix == null) "اتاق پر است یا قوانین دیتابیس اجازهٔ ورود نمی‌دهند."
                else "اتاق پر است یا ورود رد شد: $suffix"
            )
        }

        val slot = claimedSlot ?: throw IOException("برای این اتاق جای خالی پیدا نشد.")
        val slotRef = roomRef.child("slots").child(slot.toString())
        // We have claimed/refreshed this slot above. Register server-side cleanup now; rules
        // authorize it only because this UID owns the slot. If registration fails, try to release
        // the claimed slot rather than silently leaving a ghost member behind.
        try {
            slotRef.onDisconnect().removeValue().await()
        } catch (e: Exception) {
            runCatching { slotRef.removeValue().await() }
            throw IOException(friendlyError(e), e)
        }
        currentUid = uid
        currentRoom = code
        currentSlot = slot
        currentSlotRef = slotRef
        ChatPrefs.setRoomCode(code)
        attachRoomListeners(code, uid)
        return code
    }

    suspend fun sendMessage(body: String, profile: UserProfile) {
        val clean = body.trim().take(1000)
        if (clean.isEmpty()) return
        val code = currentRoom ?: throw IOException("هنوز وارد اتاق آنلاین نشده‌ای.")
        val uid = currentUid ?: auth?.currentUser?.uid ?: throw IOException("در حال اتصال مجدد هستی؛ کمی صبر کن.")
        if (connectionStatus.value != ConnectionStatus.ONLINE) throw IOException("اینترنت قطع است؛ پیام هنوز ارسال نشده.")
        val db = database ?: throw IOException("تنظیم اینترنت کامل نیست.")
        val key = db.getReference("rooms").child(code).child("messages").push().key
            ?: throw IOException("ساخت شناسه پیام ناموفق بود.")
        val payload = mapOf(
            "senderId" to uid,
            "senderName" to profile.displayName.ifBlank { "Shadow" }.trim().take(24),
            "avatar" to profile.avatar.ifBlank { "👻" }.take(8),
            "body" to clean,
            "timestamp" to System.currentTimeMillis()
        )
        try {
            db.getReference("rooms").child(code).child("messages").child(key).setValue(payload).await()
        } catch (e: Exception) {
            throw IOException(friendlyError(e), e)
        }
    }

    fun activeRoomCode(): String? = currentRoom
    fun currentUserId(): String? = currentUid

    suspend fun leaveCurrentRoom() {
        val slotRef = currentSlotRef
        detachRoomListeners()
        currentRoom = null
        currentSlot = null
        currentSlotRef = null
        mutableMembers.value = emptyList()
        if (slotRef != null) runCatching { slotRef.removeValue().await() }
    }

    private fun attachRoomListeners(code: String, uid: String) {
        detachRoomListeners()
        val db = database ?: return
        val roomRef = db.getReference("rooms").child(code)
        val slots = roomRef.child("slots")
        val memberEvents = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                mutableMembers.value = snapshot.children.mapNotNull { item ->
                    val memberUid = item.child("uid").getValue(String::class.java) ?: return@mapNotNull null
                    RoomMember(
                        uid = memberUid,
                        name = item.child("name").getValue(String::class.java) ?: "Player",
                        avatar = item.child("avatar").getValue(String::class.java) ?: "👻",
                        joinedAt = item.child("joinedAt").getValue(Long::class.java) ?: 0L,
                        slot = item.key?.toIntOrNull() ?: -1
                    )
                }.sortedBy { it.slot }
            }
            override fun onCancelled(error: DatabaseError) {
                mutableConnectionStatus.value = if (error.code == DatabaseError.DISCONNECTED) ConnectionStatus.OFFLINE else mutableConnectionStatus.value
            }
        }
        memberRef = slots
        memberListener = memberEvents
        slots.addValueEventListener(memberEvents)

        val query = roomRef.child("messages").orderByChild("timestamp").limitToLast(MAX_MESSAGES)
        val messageEvents = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val key = snapshot.key ?: return
                val senderId = snapshot.child("senderId").getValue(String::class.java) ?: return
                val stableMessageId = "firebase-$code-$key"
                if (ChatPrefs.hasMessage(stableMessageId)) return
                val message = ChatMessage(
                    id = stableMessageId,
                    roomCode = code,
                    senderId = senderId,
                    senderName = snapshot.child("senderName").getValue(String::class.java) ?: "Player",
                    avatar = snapshot.child("avatar").getValue(String::class.java) ?: "👻",
                    body = snapshot.child("body").getValue(String::class.java) ?: return,
                    timestamp = snapshot.child("timestamp").getValue(Long::class.java) ?: System.currentTimeMillis(),
                    isMine = senderId == uid
                )
                ChatPrefs.appendMessage(message)
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) = Unit
            override fun onChildRemoved(snapshot: DataSnapshot) = Unit
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) = Unit
            override fun onCancelled(error: DatabaseError) {
                if (error.code == DatabaseError.DISCONNECTED) mutableConnectionStatus.value = ConnectionStatus.OFFLINE
            }
        }
        messageQuery = query
        messageListener = messageEvents
        query.addChildEventListener(messageEvents)
    }

    private fun detachRoomListeners() {
        memberRef?.let { ref -> memberListener?.let(ref::removeEventListener) }
        messageQuery?.let { query -> messageListener?.let(query::removeEventListener) }
        memberRef = null
        memberListener = null
        messageQuery = null
        messageListener = null
    }

    private fun memberPayload(uid: String, profile: UserProfile): Map<String, Any> = mapOf(
        "uid" to uid,
        "name" to profile.displayName.ifBlank { "Shadow" }.trim().take(24),
        "avatar" to profile.avatar.ifBlank { "👻" }.take(8),
        "joinedAt" to System.currentTimeMillis()
    )

    private fun generateRoomCode(): String = buildString(8) {
        repeat(8) { append(ROOM_ALPHABET[random.nextInt(ROOM_ALPHABET.length)]) }
    }

    fun friendlyError(error: Throwable): String {
        val message = error.message.orEmpty()
        return when {
            message.contains("Permission denied", ignoreCase = true) -> "دسترسی Firebase رد شد. قوانین دیتابیس و ورود ناشناس را طبق راهنمای پروژه فعال کن."
            message.contains("network", ignoreCase = true) || message.contains("disconnected", ignoreCase = true) -> "اتصال اینترنت برقرار نیست؛ اینترنت گوشی را بررسی کن."
            message.contains("API key", ignoreCase = true) || message.contains("configuration", ignoreCase = true) -> "تنظیمات Firebase ناقص یا اشتباه است."
            message.contains("operation is not allowed", ignoreCase = true) || message.contains("ADMIN_ONLY_OPERATION", ignoreCase = true) -> "ورود ناشناس را در Firebase Authentication فعال کن."
            message.contains("expired", ignoreCase = true) -> "توکن ورود منقضی شده است؛ دوباره وارد شو."
            message.contains("timed out", ignoreCase = true) || message.contains("timeout", ignoreCase = true) -> "ارتباط با دیتابیس برقرار نشد؛ آدرس دیتابیس، اینترنت و وضعیت Firebase را بررسی کن."
            else -> message.ifBlank { "ارتباط با سرویس چت انجام نشد؛ تنظیمات Firebase و اینترنت را بررسی کن." }.take(240)
        }
    }
}
