package com.ghostchat.android.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Local profile/preferences and a bounded on-device message cache. Live group transport is handled
 * by FirebaseChatService; messages received there are cached here so the main screen and overlay
 * show the same history and unread state.
 */
object ChatPrefs {
    private const val FILE = "ghost_chat.xml"
    private const val KEY_NAME = "display_name"
    private const val KEY_AVATAR = "avatar"
    private const val KEY_ACCENT = "accent"
    private const val KEY_ROOM = "last_room"
    private const val KEY_MESSAGES = "messages_json"
    private const val KEY_ANIMATIONS = "animations"
    private const val KEY_VIBRATE = "vibrate"
    private const val KEY_COMPACT = "compact_overlay"
    private const val KEY_FIREBASE_CONFIG = "firebase_project_config"
    private const val KEY_APP_LOCK = "app_lock_enabled"
    private const val KEY_ENCRYPTION_MIGRATED = "encrypted_storage_migrated"

    private lateinit var prefs: SharedPreferences
    private lateinit var appContext: Context
    private val profileState = MutableStateFlow(UserProfile())
    private val messagesState = MutableStateFlow<List<ChatMessage>>(emptyList())
    private val appLockState = MutableStateFlow(false)
    private val appSurfaceLockedState = MutableStateFlow(false)
    @Volatile private var encryptedStorageReady = false
    private val visibleRoomsBySource = mutableMapOf<String, String>()

    val profileFlow: StateFlow<UserProfile> = profileState.asStateFlow()
    val messagesFlow: StateFlow<List<ChatMessage>> = messagesState.asStateFlow()
    val appLockFlow: StateFlow<Boolean> = appLockState.asStateFlow()
    val appSurfaceLockedFlow: StateFlow<Boolean> = appSurfaceLockedState.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (::prefs.isInitialized) return
        appContext = context.applicationContext
        val legacyPrefs = appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val securePrefs = runCatching { AndroidKeyStorePreferences(appContext, FILE) }.getOrNull()
        if (securePrefs != null) {
            // One-time migration from the previous plain SharedPreferences file into an
            // Android Keystore AES-GCM vault. Do not clear the old file unless commit succeeds.
            if (!securePrefs.getBoolean(KEY_ENCRYPTION_MIGRATED, false)) {
                val migration = securePrefs.edit()
                legacyPrefs.all.forEach { (key, value) ->
                    when (value) {
                        is String -> migration.putString(key, value)
                        is Boolean -> migration.putBoolean(key, value)
                        is Int -> migration.putInt(key, value)
                        is Long -> migration.putLong(key, value)
                        is Float -> migration.putFloat(key, value)
                        is Set<*> -> if (value.all { it is String }) {
                            @Suppress("UNCHECKED_CAST")
                            migration.putStringSet(key, (value as Set<String>).toMutableSet())
                        }
                    }
                }
                encryptedStorageReady = migration.putBoolean(KEY_ENCRYPTION_MIGRATED, true).commit()
                if (encryptedStorageReady) legacyPrefs.edit().clear().commit()
            } else {
                encryptedStorageReady = true
            }
            prefs = securePrefs
        } else {
            // Keep the app recoverable on unusual devices where Android Keystore is unavailable.
            prefs = legacyPrefs
            encryptedStorageReady = false
        }
        profileState.value = UserProfile(
            displayName = prefs.getString(KEY_NAME, "") ?: "",
            avatar = prefs.getString(KEY_AVATAR, "👻") ?: "👻",
            accent = prefs.getString(KEY_ACCENT, "cyan") ?: "cyan"
        )
        messagesState.value = decodeMessages(prefs.getString(KEY_MESSAGES, "[]") ?: "[]")
        appLockState.value = prefs.getBoolean(KEY_APP_LOCK, false)
        appSurfaceLockedState.value = appLockState.value

        // The shipped build is preconfigured for the creator's Firebase project. Seed it only
        // on a fresh install: an explicitly saved config always takes precedence so users can
        // still import another project's GC1 code or replace the configuration in Settings.
        if (prefs.getString(KEY_FIREBASE_CONFIG, null).isNullOrBlank()) {
            bundledFirebaseConfig(appContext)?.let { defaultConfig ->
                runCatching { saveFirebaseConfig(defaultConfig) }
            }
        }
    }

    private fun bundledFirebaseConfig(context: Context): FirebaseProjectConfig? = runCatching {
        val jsonText = context.assets.open("firebase-config.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val obj = JSONObject(jsonText)
        FirebaseProjectConfig(
            apiKey = obj.optString("apiKey"),
            appId = obj.optString("appId"),
            projectId = obj.optString("projectId"),
            databaseUrl = obj.optString("databaseUrl"),
            senderId = obj.optString("senderId")
        ).takeIf { it.isValid() }
    }.getOrNull()

    @Synchronized
    fun profile(): UserProfile = profileState.value

    @Synchronized
    fun saveProfile(profile: UserProfile) {
        requireReady()
        val cleanName = profile.displayName.trim().take(24)
        val saved = profile.copy(displayName = cleanName.ifBlank { "Shadow" })
        prefs.edit()
            .putString(KEY_NAME, saved.displayName)
            .putString(KEY_AVATAR, saved.avatar)
            .putString(KEY_ACCENT, saved.accent)
            .apply()
        profileState.value = saved
    }

    @Synchronized
    fun roomCode(): String = if (::prefs.isInitialized) prefs.getString(KEY_ROOM, "") ?: "" else ""

    @Synchronized
    fun setRoomCode(code: String) {
        requireReady()
        prefs.edit().putString(KEY_ROOM, code.trim().uppercase()).apply()
    }

    @Synchronized
    fun messagesForRoom(code: String): List<ChatMessage> =
        messagesState.value.filter { it.roomCode.equals(code, ignoreCase = true) }.sortedBy { it.timestamp }

    @Synchronized
    fun appendMessage(message: ChatMessage) {
        requireReady()
        if (messagesState.value.any { it.id == message.id }) return
        val roomKey = message.roomCode.trim().uppercase()
        val roomVisible = visibleRoomsBySource.values.any { it == roomKey }
        val stored = if (!message.isMine && roomVisible) message.copy(isUnread = false)
            else if (!message.isMine) message.copy(isUnread = true)
            else message.copy(isUnread = false)
        val next = (messagesState.value + stored).takeLast(400)
        messagesState.value = next
        prefs.edit().putString(KEY_MESSAGES, encodeMessages(next)).apply()
    }

    @Synchronized
    fun unreadCount(code: String): Int = messagesState.value.count {
        it.roomCode.equals(code, ignoreCase = true) && !it.isMine && it.isUnread
    }

    /** Track which UI surface is actively showing a room; incoming messages there are read. */
    @Synchronized
    fun setRoomVisible(source: String, code: String, visible: Boolean) {
        requireReady()
        val roomKey = code.trim().uppercase()
        if (visible) {
            visibleRoomsBySource[source] = roomKey
            markRoomReadInternal(roomKey)
        } else if (visibleRoomsBySource[source] == roomKey) {
            visibleRoomsBySource.remove(source)
        }
    }

    @Synchronized
    fun markRoomRead(code: String) {
        requireReady()
        markRoomReadInternal(code.trim().uppercase())
    }

    private fun markRoomReadInternal(roomKey: String) {
        val current = messagesState.value
        var changed = false
        val next = current.map { message ->
            if (message.roomCode.equals(roomKey, ignoreCase = true) && message.isUnread) {
                changed = true
                message.copy(isUnread = false)
            } else message
        }
        if (changed) {
            messagesState.value = next
            prefs.edit().putString(KEY_MESSAGES, encodeMessages(next)).apply()
        }
    }

    @Synchronized
    fun hasMessage(id: String): Boolean = messagesState.value.any { it.id == id }

    @Synchronized
    fun firebaseConfig(): FirebaseProjectConfig? {
        if (!::prefs.isInitialized) return null
        val raw = prefs.getString(KEY_FIREBASE_CONFIG, null) ?: return null
        return runCatching {
            val obj = JSONObject(raw)
            FirebaseProjectConfig(
                apiKey = obj.optString("apiKey"),
                appId = obj.optString("appId"),
                projectId = obj.optString("projectId"),
                databaseUrl = obj.optString("databaseUrl"),
                senderId = obj.optString("senderId")
            ).takeIf { it.isValid() }
        }.getOrNull()
    }

    @Synchronized
    fun saveFirebaseConfig(config: FirebaseProjectConfig) {
        requireReady()
        require(config.isValid()) { "Invalid Firebase configuration" }
        val json = JSONObject().apply {
            put("apiKey", config.apiKey.trim())
            put("appId", config.appId.trim())
            put("projectId", config.projectId.trim())
            put("databaseUrl", config.databaseUrl.trim().trimEnd('/'))
            put("senderId", config.senderId.trim())
        }
        prefs.edit().putString(KEY_FIREBASE_CONFIG, json.toString()).apply()
    }


    @Synchronized
    fun clearAllMessages() {
        requireReady()
        messagesState.value = emptyList()
        prefs.edit().putString(KEY_MESSAGES, "[]").apply()
    }

    @Synchronized
    fun clearMessagesForRoom(code: String) {
        requireReady()
        val next = messagesState.value.filterNot { it.roomCode.equals(code, ignoreCase = true) }
        messagesState.value = next
        prefs.edit().putString(KEY_MESSAGES, encodeMessages(next)).apply()
    }

    fun animationsEnabled(): Boolean = if (::prefs.isInitialized) prefs.getBoolean(KEY_ANIMATIONS, true) else true
    fun setAnimationsEnabled(value: Boolean) { requireReady(); prefs.edit().putBoolean(KEY_ANIMATIONS, value).apply() }
    fun vibrationEnabled(): Boolean = if (::prefs.isInitialized) prefs.getBoolean(KEY_VIBRATE, false) else false
    fun setVibrationEnabled(value: Boolean) { requireReady(); prefs.edit().putBoolean(KEY_VIBRATE, value).apply() }
    fun compactOverlay(): Boolean = if (::prefs.isInitialized) prefs.getBoolean(KEY_COMPACT, false) else false
    fun setCompactOverlay(value: Boolean) { requireReady(); prefs.edit().putBoolean(KEY_COMPACT, value).apply() }

    fun appLockEnabled(): Boolean = appLockState.value
    fun setAppLockEnabled(value: Boolean) {
        requireReady()
        prefs.edit().putBoolean(KEY_APP_LOCK, value).apply()
        appLockState.value = value
        appSurfaceLockedState.value = false
    }
    fun setAppSurfaceLocked(value: Boolean) {
        if (!::prefs.isInitialized) return
        appSurfaceLockedState.value = value && appLockState.value
    }
    fun isAppSurfaceLocked(): Boolean = appSurfaceLockedState.value
    fun isLocalStorageEncrypted(): Boolean = encryptedStorageReady

    private fun requireReady() {
        check(::prefs.isInitialized) { "ChatPrefs.init(context) must be called first" }
    }

    private fun encodeMessages(messages: List<ChatMessage>): String {
        val array = JSONArray()
        messages.forEach { m ->
            array.put(JSONObject().apply {
                put("id", m.id)
                put("roomCode", m.roomCode)
                put("senderId", m.senderId)
                put("senderName", m.senderName)
                put("avatar", m.avatar)
                put("body", m.body)
                put("timestamp", m.timestamp)
                put("isMine", m.isMine)
                put("isUnread", m.isUnread)
            })
        }
        return array.toString()
    }

    private fun decodeMessages(raw: String): List<ChatMessage> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                add(
                    ChatMessage(
                        id = obj.optString("id", "local-$i"),
                        roomCode = obj.optString("roomCode", ""),
                        senderId = obj.optString("senderId", "local"),
                        senderName = obj.optString("senderName", "Shadow"),
                        avatar = obj.optString("avatar", "👻"),
                        body = obj.optString("body", ""),
                        timestamp = obj.optLong("timestamp", 0L),
                        isMine = obj.optBoolean("isMine", false),
                        isUnread = obj.optBoolean("isUnread", false)
                    )
                )
            }
        }
    }.getOrDefault(emptyList())
}
