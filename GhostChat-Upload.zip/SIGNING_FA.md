# امضای امن نسخهٔ Release — Ghost Chat 1.0.0

## نسخه
- `versionCode = 1` (نسخهٔ اولیه)
- `versionName = 1.0.0`
- نام بسته: `com.ghostchat.android`

## چرا کلید امضا داخل ZIP نیست؟
فایل keystore کلید خصوصی مالک برنامه است. قرار دادن آن در مخزن یا ZIP قابل‌اشتراک امن نیست. اگر کلید گم شود، انتشار به‌روزرسانی روی همان نصب قبلی ممکن است دشوار یا ناممکن شود؛ آن را در جای امن و پشتیبان رمزگذاری‌شده نگه دار و با کسی به اشتراک نگذار.

## ساخت کلید روی رایانهٔ خودت
اگر Android Studio / Java روی رایانه داری، این دستور را اجرا کن و اطلاعات واقعی خودت را به‌جای نمونه وارد کن:

```bash
keytool -genkeypair -v -keystore ghostchat-release.jks -keyalg RSA -keysize 3072 -validity 10000 -alias ghostchat
```

رمزها را در جای امن ذخیره کن. فایل `ghostchat-release.jks` را داخل GitHub repository قرار نده.

## ثبت GitHub Secrets
در GitHub برو به: **Repository → Settings → Secrets and variables → Actions → New repository secret**. این ۴ Secret را اضافه کن:

- `ANDROID_KEYSTORE_BASE64`: محتوای Base64 فایل keystore. در macOS/Linux با `base64 -i ghostchat-release.jks | tr -d '\n'` ساخته می‌شود.
- `ANDROID_KEYSTORE_PASSWORD`: رمز keystore.
- `ANDROID_KEY_ALIAS`: در نمونهٔ بالا `ghostchat`.
- `ANDROID_KEY_PASSWORD`: رمز کلید.

هیچ‌کدام از رمزها را در سورس، پیام عمومی، یا فایل Workflow hardcode نکن.

## ساخت نسخهٔ امضاشده
مخزن → **Actions → Build signed Ghost Chat release APK → Run workflow**. اگر Secrets درست باشند، مرحلهٔ بررسی امضا اجرا می‌شود و APK در Artifacts با نام `GhostChat-signed-release-v1.0.0` قرار می‌گیرد.

## Debug در برابر Release
Workflow عادی یک APK آزمایشی Debug می‌سازد که با کلید debug خودکار اندروید امضا می‌شود. آن را برای تست بگیر، نه انتشار رسمی. Release فقط با keystore خصوصی خودت امضا می‌شود.
