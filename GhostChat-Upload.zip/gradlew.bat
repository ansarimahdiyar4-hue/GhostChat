@echo off
setlocal EnableExtensions
set VERSION=8.13
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set INSTALL_ROOT=%GRADLE_USER_HOME%\ghost-chat-wrapper
set GRADLE_HOME=%INSTALL_ROOT%\gradle-%VERSION%
set GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat
if exist "%GRADLE_BIN%" goto runGradle
if not exist "%INSTALL_ROOT%" mkdir "%INSTALL_ROOT%"
echo Gradle %VERSION% is not cached; downloading it now...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%INSTALL_ROOT%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%INSTALL_ROOT%\gradle-%VERSION%-bin.zip' '%INSTALL_ROOT%'"
if errorlevel 1 exit /b %errorlevel%
del "%INSTALL_ROOT%\gradle-%VERSION%-bin.zip"
:runGradle
call "%GRADLE_BIN%" -p "%~dp0" %*
exit /b %errorlevel%
