# ساخت APK نصب‌شدنی با GitHub Actions

## ۱. قرار دادن پروژه روی GitHub

1. `GhostChat-Ultimate-v1.0.0.zip` را استخراج کن.
2. یک repository تازه بساز.
3. **محتویات داخل پوشهٔ پروژه** را در ریشهٔ مخزن بارگذاری کن؛ خود فایل ZIP را به‌تنهایی بارگذاری نکن.
4. مطمئن شو مسیر `.github/workflows/build-apk.yml` و پوشه‌های `app/` و `firebase/` حفظ شده‌اند.
5. فایل `google-services.json` یا هر کلید Service Account را در repository قرار نده. پیکربندی عمومی کلاینت در `app/src/main/assets/firebase-config.json` از قبل در سورس آمده است؛ این فایل حاوی کلید Admin نیست.

## ۲. اجرای ساخت

- پس از push روی `main` یا `master`، مخزن → **Actions** → اجرای **Build Ghost Chat APK** را باز کن.
- یا از **Run workflow** اجرای دستی شروع کن.
- پس از سبز شدن مراحل، قسمت **Artifacts** را باز و `GhostChat-debug-APK` را دانلود کن. Workflow بررسی می‌کند APK با امضای Debug اندروید قابل‌اعتبارسنجی باشد.
- ZIP آرتیفکت را استخراج کن و `app-debug.apk` را روی گوشی نصب کن.

## ۳. اتصال واقعی پیام‌ها

ساخت APK فقط فایل برنامه را می‌سازد؛ Firebase باید فعال باشد. این بسته به پروژهٔ سازنده `ghostchat-73b36` پیکربندی شده است. برای چت، Anonymous Authentication را روشن نگه دار و قواعد به‌روز `firebase/database.rules.json` را در Realtime Database → Rules منتشر کن. با همین APK، گوشی‌ها خودکار از تنظیمات یکسان استفاده می‌کنند؛ سازنده تنها کد اتاق را برای دوستان می‌فرستد. راهنمای دقیق در `FIREBASE_SETUP_FA.md` است.

## ۴. ساخت Release امضاشده

برای نصب و تست، APK Debug کافی است. برای انتشار/آپدیت طولانی‌مدت، کلید امضای شخصی لازم است. راهنمای ساخت keystore و ثبت چهار GitHub Secret در [`SIGNING_FA.md`](SIGNING_FA.md) است. پس از ثبت Secretها، در **Actions → Build signed Ghost Chat release APK → Run workflow** ساخت Release را اجرا کن. مرحلهٔ `apksigner verify` امضا را بررسی می‌کند. کلید keystore را هرگز داخل مخزن قرار نده.

## ۵. عیب‌یابی

- خطای `Permission denied`: Anonymous Auth یا Rules را بررسی کن.
- خطای timeout یا عدم اتصال: آدرس Realtime Database را دقیقاً از Firebase Console بردار و اینترنت را بررسی کن.
- خطای کامپایل: لاگ کامل مرحلهٔ Build را در GitHub Actions باز کن؛ به‌خصوص اولین خط قرمز مربوط به Gradle/Kotlin را بررسی کن.

APK ساخته‌شده debug است و برای نصب/آزمایش مناسب است؛ انتشار رسمی نیازمند امضای Release و بررسی امنیتی است.
